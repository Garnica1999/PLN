"""10_evaluar_sentencia.py
Fecha: 2026-09-09
Descripcion: CLI del producto final Juris-PLN (Fase N). Dada una sentencia
    (archivo de texto, id del corpus o texto literal) produce un JSON con:
    (1) validacion M0 de que es providencia de la Corte Constitucional,
    (2) area tematica M4 (clasificador LogReg sobre lemas enmascarados),
    (3) articulos de la Constitucion Politica vinculados (extraccion M2 +
    expansion M7 v2 BM25 por pasajes), (4) contexto jurisprudencial M5
    (sentencias citadas resueltas al corpus con PageRank y area) y un
    resumen breve. Salida JSON a stdout y opcionalmente a --salida RUTA.
Estado del arte aplicado: heuristica M0 (accuracy 1.0), NER regex M2,
    TF-IDF de lemas enmascarados + LogReg multinomial (macro-F1 0.287),
    BM25 por pasajes con max-pooling de chunks y bigramas LLR (F1@5 0.218),
    PageRank de la red de citas (M5).
"""

import argparse
import json
import sys
import time
import traceback
from pathlib import Path

import pandas as pd
from lib.componentes_producto import (
    ClasificadorArea,
    ContextoJurisprudencial,
    ExtractorEntidades,
    ValidadorEntrada,
    VinculoCP,
)

CONFIG = {
    "ruta_corpus": "data/corpus_sentencias.parquet",
    "k_bm25": 5,
    "max_citas_resumen": 5,
    "max_arts_resumen": 5,
}

ROOT = Path(__file__).resolve().parent.parent


# ===== SECCION 1: entrada de datos =====
def leer_archivo(ruta: str) -> str:
    """Lee un archivo de texto UTF-8 (con fallback latin-1).

    Args:
        ruta: Ruta al archivo .txt de la sentencia.

    Returns:
        Contenido del archivo como cadena.

    Raises:
        SystemExit: Si el archivo no existe o esta vacio (mensaje accionable).
    """
    archivo = Path(ruta)
    if not archivo.is_file():
        raise SystemExit(
            f"Error: el archivo no existe: {ruta}. Verifique la ruta o use "
            "--id/--texto con el contenido de la sentencia."
        )
    try:
        texto = archivo.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        texto = archivo.read_text(encoding="latin-1")
    if not texto.strip():
        raise SystemExit(
            f"Error: el archivo esta vacio: {ruta}. Proporcione una sentencia "
            "con contenido."
        )
    return texto


def texto_por_id(id_corpus: str) -> tuple[str, str]:
    """Resuelve un id del corpus a su texto crudo y limpio.

    Args:
        id_corpus: Id numerico del documento en data/corpus_sentencias.parquet.

    Returns:
        Tupla (texto_crudo, texto_limpio) del documento.

    Raises:
        SystemExit: Si el id no existe en el corpus (mensaje accionable).
    """
    corpus = pd.read_parquet(
        ROOT / CONFIG["ruta_corpus"], columns=["id", "texto", "texto_limpio"]
    )
    fila = corpus[corpus["id"].astype(str) == str(id_corpus)]
    if fila.empty:
        raise SystemExit(
            f"Error: el id {id_corpus} no existe en el corpus "
            f"({len(corpus)} sentencias). Ejecute el producto con un id "
            "valido o use --archivo/--texto."
        )
    return (
        str(fila["texto"].iloc[0]),
        str(fila["texto_limpio"].iloc[0]),
    )


# ===== SECCION 2: orquestacion del producto =====
def construir_salida(
    texto_crudo: str,
    texto_limpio: str,
    id_entrada: str | None,
    componentes: dict,
) -> dict:
    """Ejecuta los cinco componentes del producto sobre una sentencia.

    Args:
        texto_crudo: Texto crudo de la sentencia (M0/M2/M4).
        texto_limpio: Texto limpio del corpus (M7) o copia del crudo.
        id_entrada: Id del corpus si la entrada fue --id; None si no.
        componentes: Dict con validador, extractor, clasificador, vinculo y
            contexto ya inicializados.

    Returns:
        Dict JSON-serializable con la estructura del producto:
        es_sentencia, score_validacion, id_detectado, ponente, area,
        articulos_cp, sentencias_citadas y resumen.
    """
    validador: ValidadorEntrada = componentes["validador"]
    extractor: ExtractorEntidades = componentes["extractor"]
    clasificador: ClasificadorArea = componentes["clasificador"]
    vinculo: VinculoCP = componentes["vinculo"]
    contexto: ContextoJurisprudencial = componentes["contexto"]

    validacion = validador.validar(texto_crudo)
    es_sentencia = validacion["es_sentencia"]

    # Componentes que solo aplican a providencias validas.
    if es_sentencia:
        entidades = extractor.extraer(texto_crudo)
        canon_detectado = extractor.detectar_canon_encabezado(texto_crudo)
        id_detectado = (
            contexto.id_de_canon(canon_detectado) if canon_detectado else None
        )
        area = clasificador.clasificar(texto_crudo)
        extraidos = []
        for canon in entidades["arts_cp"]:
            detalle = vinculo.detalle_articulo(canon)
            if detalle is None:
                continue
            extraidos.append({"numero": canon, **detalle})
        recuperados = vinculo.recuperar(texto_limpio, CONFIG["k_bm25"])
        # M5 excluye self-loops: la autocita del encabezado (canon propio)
        # no es una sentencia citada por el documento.
        citas = [
            c for c in entidades["sents_citadas"] if c != canon_detectado
        ]
        citadas = contexto.resolver(citas)
        ponente = entidades["ponente"]
    else:
        area = None
        extraidos = []
        recuperados = []
        citadas = []
        ponente = None
        id_detectado = None

    salida = {
        "es_sentencia": es_sentencia,
        "score_validacion": validacion["score_validacion"],
        "id_detectado": id_detectado if id_entrada is None else str(id_entrada),
        "ponente": ponente,
        "area": area,
        "articulos_cp": {
            "extraidos": extraidos,
            "recuperados_bm25": recuperados,
        },
        "sentencias_citadas": citadas,
        "resumen": construir_resumen(
            es_sentencia, area, extraidos, recuperados, citadas
        ),
    }
    return salida


def construir_resumen(
    es_sentencia: bool,
    area: dict | None,
    extraidos: list[dict],
    recuperados: list[dict],
    citadas: list[dict],
) -> str:
    """Redacta el resumen breve de una linea del resultado.

    Args:
        es_sentencia: Decision M0.
        area: Dict del clasificador M4 (top3/via) o None.
        extraidos: Articulos CP extraidos por M2 con detalle.
        recuperados: Articulos CP recuperados por BM25 (M7).
        citadas: Sentencias citadas resueltas por M5.

    Returns:
        Cadena con el resumen legible del analisis.
    """
    if not es_sentencia:
        return (
            "El texto no cumple la heuristica de providencia de la Corte "
            "Constitucional (menos de 2/3 reglas); no se ejecutaron los "
            "componentes de analisis."
        )
    top1 = area["top3"][0] if area and area["top3"] else None
    parte_area = (
        f"area tematica {top1['area']} (prob {top1['prob']})"
        if top1
        else "sin area"
    )
    n_resueltas = sum(1 for c in citadas if c["resuelta"])
    return (
        f"Providencia valida de la Corte Constitucional; {parte_area}; "
        f"{len(extraidos)} articulos CP extraidos y {len(recuperados)} "
        f"recuperados por BM25; {n_resueltas} de {len(citadas)} sentencias "
        "citadas resueltas al corpus."
    )


def inicializar_componentes() -> dict:
    """Inicializa los cinco componentes del producto (una vez por proceso).

    Returns:
        Dict con validador, extractor, clasificador, vinculo y contexto.
    """
    return {
        "validador": ValidadorEntrada(),
        "extractor": ExtractorEntidades(),
        "clasificador": ClasificadorArea(),
        "vinculo": VinculoCP(),
        "contexto": ContextoJurisprudencial(),
    }


# ===== SECCION 3: CLI =====
def parsear_args() -> argparse.Namespace:
    """Define y parsea los argumentos de linea de comandos.

    Returns:
        Namespace con archivo, id, texto y salida.
    """
    parser = argparse.ArgumentParser(
        description=(
            "Evalua una sentencia de la Corte Constitucional: validacion M0, "
            "area tematica M4, articulos CP (M2+M7) y contexto M5."
        )
    )
    grupo = parser.add_mutually_exclusive_group(required=True)
    grupo.add_argument(
        "--archivo", help="Ruta a un archivo .txt con la sentencia"
    )
    grupo.add_argument(
        "--id", dest="id_corpus", help="Id del documento en el corpus"
    )
    grupo.add_argument(
        "--texto", help="Texto literal de la sentencia entre comillas"
    )
    parser.add_argument(
        "--salida",
        help="Ruta opcional donde guardar el JSON de salida",
    )
    return parser.parse_args()


def main() -> None:
    """Orquesta el CLI: resuelve la entrada, evalua y emite el JSON."""
    inicio = time.time()
    args = parsear_args()
    try:
        if args.archivo:
            texto_crudo = leer_archivo(args.archivo)
            texto_limpio = texto_crudo
            id_entrada = None
        elif args.id_corpus:
            texto_crudo, texto_limpio = texto_por_id(args.id_corpus)
            id_entrada = str(args.id_corpus)
        else:
            texto_crudo = args.texto
            texto_limpio = texto_crudo
            id_entrada = None
        if not texto_crudo.strip():
            raise SystemExit(
                "Error: el texto de entrada esta vacio. Proporcione una "
                "sentencia con contenido."
            )

        componentes = inicializar_componentes()
        salida = construir_salida(
            texto_crudo, texto_limpio, id_entrada, componentes
        )
        salida["tiempo_segundos"] = round(time.time() - inicio, 2)

        json_texto = json.dumps(salida, ensure_ascii=False, indent=2)
        print(json_texto)
        if args.salida:
            ruta = Path(args.salida)
            ruta.parent.mkdir(parents=True, exist_ok=True)
            ruta.write_text(json_texto + "\n", encoding="utf-8")
            print(
                f"[info] JSON guardado en {ruta}",
                file=sys.stderr,
            )
    except SystemExit as exc:
        # SystemExit llega desde leer_archivo/texto_por_id con el mensaje
        # accionable; se imprime una sola vez y se sale con codigo 1.
        if exc.code and isinstance(exc.code, str):
            print(f"[error] {exc.code}", file=sys.stderr)
        sys.exit(1)
    except Exception:  # noqa: BLE001 - main captura todo para traceback + exit 1
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
