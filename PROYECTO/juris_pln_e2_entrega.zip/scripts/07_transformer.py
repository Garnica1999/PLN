"""Transformer M4 (Fase L3): fine-tuning BETO para area tematica.

Pipeline (ADR-3, ADR-6):
    1. Carga splits oficiales (data/splits_m4.parquet) + etiquetas.
    2. Texto crudo (sin lematizar; ADR-6) truncado cabeza+cola 256+256
       tokens (ADR-3 variante a) y experimento chunk-mean (variante b)
       si el tiempo lo permite.
    3. Fine-tuning BETO (dccuchile/bert-base-spanish-wwm-cased) en GPU
       con guard de VRAM: espera hasta haber >=6 GB libres.
    4. Doble escenario (ADR-2): completo vs citas enmascaradas sobre el
       texto crudo (regex M2 portado, enmascara "articulo N ... constitucion",
       "ley N de AAAA", "T-293 de 1997" por [CITA]).
    5. Metricas macro-F1/accuracy en test para ambos escenarios; guardado
       de modelos y metricas acumulativas.

Uso:
    /home/carlos/venv/bin/python scripts/07_transformer.py
"""

import json
import logging
import re
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
import torch
from sklearn.metrics import accuracy_score, f1_score
from torch.utils.data import DataLoader, Dataset
from transformers import (
    AutoModelForSequenceClassification,
    AutoTokenizer,
    get_linear_schedule_with_warmup,
)

# ===== SECCION 1: configuracion =====
CONFIG = {
    "semilla": 42,
    "modelo": "dccuchile/bert-base-spanish-wwm-cased",
    "max_tokens": 512,  # 256 cabeza + 256 cola (ADR-3)
    "batch_train": 8,
    "batch_eval": 16,
    "grad_accum": 4,  # batch efectivo 32
    "epochs": 3,
    "lr": 2e-5,
    "vram_min_gb": 6.0,
    "vram_espera_seg": 300,  # reintento cada 5 min
    "vram_max_esperas": 288,  # hasta 24 h
    "ruta_splits": "data/splits_m4.parquet",
    "ruta_corpus": "data/corpus_sentencias.parquet",
    "ruta_etiquetas": "data/etiquetas_areas.parquet",
    "dir_modelos": "modelos/m4_transformer",
    "ruta_metricas": "resultados/m4_transformer.json",
    "ruta_log": "experimentos/m4_transformer.log",
}

LOGGER = logging.getLogger("m4_transformer")

# Enmascarado sobre TEXTO CRUDO (mas fiable que a nivel de lemas).
# v2 (2026-09-09): grupos secuenciales sin retroceso anomalo; series
# "11, 13 y 86" en una sola CITA; sin sufijos [A-C] (falso con C.P.).
RE_CITA_CRUDO = re.compile(
    r"(?:(?:art[ií]culos?|art\.?)\s*\d{1,4}(?:\s*(?:bis|ter|quáter)\b)?"
    r"(?:\s*,?\s*(?:y|,|e)\s*(?:el\s+)?(?:art[ií]culo\s*)?\d{1,4})*"
    r"(?:\s+(?:de|del)\s+(?:la\s+)?(?:Constituci[oó]n(?:\s+Pol[ií]tica)?|C\.?\s?P\.?))?"
    r")"
    r"|(?:(?:ley(?:es)?|decretos?(?:\s+ley)?|acto\s+legislativo)\s+\d{1,4}"
    r"(?:\s+de\s+(?:19|20)\d{2})?"
    r")"
    r"|\b[CTS]U?\s?-?\s?\d{1,4}\s+(?:de\s+|/)\s?(?:19|20)\d{2}\b",
    re.IGNORECASE,
)


def configurar_logging() -> logging.Logger:
    """Configura el logger del experimento."""
    Path(CONFIG["ruta_log"]).parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[
            logging.FileHandler(CONFIG["ruta_log"], mode="w"),
            logging.StreamHandler(),
        ],
    )
    return LOGGER


def esperar_vram() -> torch.device:
    """Espera ciclicamente hasta que la GPU tenga VRAM libre suficiente.

    Returns:
        Dispositivo cuda cuando hay >=vram_min_gb libres.
    """
    dispositivo = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if dispositivo.type != "cuda":
        LOGGER.warning("sin CUDA: continuaria en CPU (inviable para fine-tuning)")
        return dispositivo
    esperas = 0
    while True:
        libre, _ = torch.cuda.mem_get_info()
        gb = libre / 1e9
        if gb >= CONFIG["vram_min_gb"]:
            LOGGER.info("VRAM libre %.1f GB: suficiente", gb)
            return dispositivo
        esperas += 1
        if esperas > CONFIG["vram_max_esperas"]:
            raise RuntimeError(f"VRAM insuficiente tras {esperas} esperas ({gb:.1f} GB)")
        LOGGER.info("VRAM libre %.1f GB < %.1f: espero %d s (intento %d)", gb, CONFIG["vram_min_gb"], CONFIG["vram_espera_seg"], esperas)
        time.sleep(CONFIG["vram_espera_seg"])


def enmascarar_texto_crudo(texto: str) -> str:
    """Enmascara citas normativas en el texto crudo con [CITA].

    Args:
        texto: Texto crudo de la sentencia.

    Returns:
        Texto con las citas reemplazadas por [CITA].
    """
    return RE_CITA_CRUDO.sub("[CITA]", texto)


def cargar_datos() -> pd.DataFrame:
    """Carga corpus + etiquetas + splits oficiales.

    Returns:
        DataFrame con id, texto, area y particion.
    """
    corpus = pq.read_table(CONFIG["ruta_corpus"], columns=["id", "texto"]).to_pandas()
    etiquetas = pq.read_table(CONFIG["ruta_etiquetas"], columns=["id", "area_primaria"]).to_pandas()
    splits = pq.read_table(CONFIG["ruta_splits"]).to_pandas()
    df = corpus.merge(etiquetas, on="id").merge(splits, on="id")
    df = df[df["area_primaria"] != "sin_area_definida"].reset_index(drop=True)
    # Clases raras agrupadas igual que en 06 (consistencia de etiquetas).
    conteo = df["area_primaria"].value_counts()
    raras = conteo[conteo < 3].index.tolist()
    if raras:
        df.loc[df["area_primaria"].isin(raras), "area_primaria"] = "otras_areas"
    df["texto_mask"] = df["texto"].map(enmascarar_texto_crudo)
    LOGGER.info("datos: %d filas, %d clases", len(df), df["area_primaria"].nunique())
    return df


class SentenciasDataset(Dataset):
    """Dataset de sentencias tokenizadas cabeza+cola para BETO."""

    def __init__(self, textos: pd.Series, etiquetas: pd.Series, tokenizer, clases: dict):
        self.textos = textos.tolist()
        self.etiquetas = etiquetas.map(clases).tolist()
        self.tokenizer = tokenizer

    def __len__(self) -> int:
        return len(self.textos)

    def __getitem__(self, idx: int) -> dict:
        texto = self.textos[idx]
        # Truncamiento cabeza+cola (ADR-3): tokenizar completo con
        # truncamiento largo y reconstruir 256+256.
        enc = self.tokenizer(
            texto,
            max_length=CONFIG["max_tokens"],
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )
        return {
            "input_ids": enc["input_ids"].squeeze(0),
            "attention_mask": enc["attention_mask"].squeeze(0),
            "labels": torch.tensor(self.etiquetas[idx], dtype=torch.long),
        }


def entrenar_beto(df: pd.DataFrame, columna: str, dispositivo: torch.device, etiqueta: str) -> dict:
    """Fine-tunea BETO en un escenario y evalua en test.

    Args:
        df: DataFrame con texto, area y particion.
        columna: texto (completo) o texto_mask (enmascarado).
        dispositivo: cuda/cpu.
        etiqueta: Nombre del escenario para logs/guardado.

    Returns:
        Dict con macro_f1, accuracy y ruta del modelo.
    """
    torch.manual_seed(CONFIG["semilla"])
    np.random.seed(CONFIG["semilla"])
    tokenizer = AutoTokenizer.from_pretrained(CONFIG["modelo"])
    clases = {c: i for i, c in enumerate(sorted(df["area_primaria"].unique()))}

    tr = df[df["particion"] == "train"]
    va = df[df["particion"] == "val"]
    te = df[df["particion"] == "test"]
    dl_tr = DataLoader(SentenciasDataset(tr[columna], tr["area_primaria"], tokenizer, clases), batch_size=CONFIG["batch_train"], shuffle=True)
    dl_va = DataLoader(SentenciasDataset(va[columna], va["area_primaria"], tokenizer, clases), batch_size=CONFIG["batch_eval"])
    dl_te = DataLoader(SentenciasDataset(te[columna], te["area_primaria"], tokenizer, clases), batch_size=CONFIG["batch_eval"])

    modelo = AutoModelForSequenceClassification.from_pretrained(
        CONFIG["modelo"], num_labels=len(clases)
    ).to(dispositivo)
    optimizador = torch.optim.AdamW(modelo.parameters(), lr=CONFIG["lr"])
    total_pasos = len(dl_tr) * CONFIG["epochs"] // CONFIG["grad_accum"]
    scheduler = get_linear_schedule_with_warmup(optimizador, int(0.06 * total_pasos), total_pasos)

    mejor_f1 = -1.0
    ruta_modelo = f"{CONFIG['dir_modelos']}/beto_{etiqueta}"
    modelo.train()
    paso = 0
    for epoca in range(CONFIG["epochs"]):
        perdida_epoca = 0.0
        for i, lote in enumerate(dl_tr):
            lote = {k: v.to(dispositivo) for k, v in lote.items()}
            salida = modelo(**lote)
            perdida = salida.loss / CONFIG["grad_accum"]
            perdida.backward()
            perdida_epoca += salida.loss.item()
            if (i + 1) % CONFIG["grad_accum"] == 0:
                torch.nn.utils.clip_grad_norm_(modelo.parameters(), 1.0)
                optimizador.step()
                scheduler.step()
                optimizador.zero_grad()
                paso += 1
        # Validacion al final de cada epoca.
        f1_va = evaluar_beto(modelo, dl_va, dispositivo)
        LOGGER.info("[%s] epoca %d: perdida=%.4f macro-F1 val=%.4f", etiqueta, epoca + 1, perdida_epoca / len(dl_tr), f1_va)
        if f1_va > mejor_f1:
            mejor_f1 = f1_va
            Path(CONFIG["dir_modelos"]).mkdir(parents=True, exist_ok=True)
            modelo.save_pretrained(ruta_modelo)
            tokenizer.save_pretrained(ruta_modelo)

    # Evaluar el mejor checkpoint en test.
    modelo = AutoModelForSequenceClassification.from_pretrained(ruta_modelo).to(dispositivo)
    y_pred, y_true = predecir(modelo, dl_te, dispositivo)
    inv = {v: k for k, v in clases.items()}
    y_pred_lbl = [inv[int(p)] for p in y_pred]
    y_true_lbl = [inv[int(t)] for t in y_true]
    return {
        "macro_f1": float(f1_score(y_true_lbl, y_pred_lbl, average="macro")),
        "accuracy": float(accuracy_score(y_true_lbl, y_pred_lbl)),
        "modelo": ruta_modelo,
        "mejor_f1_val": float(mejor_f1),
    }


def evaluar_beto(modelo, dl: DataLoader, dispositivo: torch.device) -> float:
    """Calcula macro-F1 de un modelo sobre un DataLoader.

    Args:
        modelo: Modelo BETO.
        dl: DataLoader de evaluacion.
        dispositivo: cuda/cpu.

    Returns:
        macro-F1.
    """
    modelo.eval()
    y_pred, y_true = predecir(modelo, dl, dispositivo)
    return f1_score(y_true, y_pred, average="macro")


def predecir(modelo, dl: DataLoader, dispositivo: torch.device) -> tuple[list, list]:
    """Predice etiquetas (codes) sobre un DataLoader.

    Args:
        modelo: Modelo BETO.
        dl: DataLoader.
        dispositivo: cuda/cpu.

    Returns:
        Tupla (y_pred codes, y_true codes).
    """
    modelo.eval()
    preds, trues = [], []
    with torch.no_grad():
        for lote in dl:
            mask = lote["attention_mask"].to(dispositivo)
            ids = lote["input_ids"].to(dispositivo)
            etiquetas = lote["labels"]
            logits = modelo(input_ids=ids, attention_mask=mask).logits
            preds.extend(torch.argmax(logits, dim=-1).cpu().tolist())
            trues.extend(etiquetas.tolist())
    return preds, trues


def main() -> None:
    """Ejecuta el fine-tuning BETO en ambos escenarios."""
    t0 = time.time()
    LOGGER.info("inicio transformer M4 (BETO)")
    dispositivo = esperar_vram()
    if dispositivo.type != "cuda":
        raise RuntimeError("fine-tuning BETO requiere GPU; aborta (documentado)")
    df = cargar_datos()
    resultados = {"fecha": pd.Timestamp.now().isoformat(), "config": CONFIG, "modelo": CONFIG["modelo"]}
    for escenario, columna in [("completo", "texto"), ("enmascarado", "texto_mask")]:
        LOGGER.info("fine-tuning escenario %s", escenario)
        resultados[escenario] = entrenar_beto(df, columna, dispositivo, escenario)
        LOGGER.info("[%s] macro-F1 test=%.4f acc=%.4f", escenario, resultados[escenario]["macro_f1"], resultados[escenario]["accuracy"])
    resultados["gap_leakage"] = resultados["completo"]["macro_f1"] - resultados["enmascarado"]["macro_f1"]
    resultados["tiempo_total_seg"] = time.time() - t0
    with open(CONFIG["ruta_metricas"], "w", encoding="utf-8") as f:
        json.dump(resultados, f, ensure_ascii=False, indent=2, default=str)
    LOGGER.info("fin en %.0f s; gap leakage=%.4f", resultados["tiempo_total_seg"], resultados["gap_leakage"])


if __name__ == "__main__":
    configurar_logging()
    main()
