"""Baseline clasico M4: clasificacion de area tematica constitucional.

Pipeline (Fase L1, ADR-2/6/8):
    1. Carga lemas por documento + etiquetas de area (via Constitucion).
    2. Split estratificado 70/15/15 UNA VEZ (seed 42) guardado en
       data/splits_m4.parquet.
    3. Escenario A (completo): TF-IDF sobre lemas + LinearSVC / LogReg.
       Escenario B (enmascarado): citas normativas enmascaradas con [CITA]
       a nivel de lemas (aproximacion documentada) + mismos modelos.
    4. Metricas macro-F1/accuracy/F1 por clase en test (tabla 2x2 modelo x
       escenario), matriz de confusion, SHAP del mejor lineal.
    5. Guardado de metricas, figuras y modelo.

Notas:
    - Los lemas multi-palabra de spaCy ("hacer el") se normalizan a
      "hacer_el" (guion bajo) antes de vectorizar (hallazgo Fase J).
    - El enmascarado a nivel de lemas es una aproximacion: los patrones de
      cita ya estan lematizados; se enmascaran secuencias lema-numeral
      tipicas de citas (articulo N, ley N, sentencia T-N de AAAA).

Uso:
    /home/carlos/venv/bin/python scripts/06_baseline_clasico.py
"""

import json
import logging
import re
import time
from pathlib import Path

import joblib
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import optuna
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from scipy.sparse import vstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC

# ===== SECCION 1: configuracion =====
CONFIG = {
    "semilla": 42,
    "min_df": 3,
    "max_features": 100000,  # reducido 200k->100k por OOM con job externo en RAM
    "ngram": (1, 2),
    "optuna_trials": 15,  # reducido 25->15 por OOM con job externo en RAM
    "shap_muestra": 500,
    "ruta_lemas": "data/lemas_por_doc.parquet",
    "ruta_etiquetas": "data/etiquetas_areas.parquet",
    "ruta_splits": "data/splits_m4.parquet",
    "dir_modelo": "modelos/m4_baseline",
    "ruta_metricas": "resultados/m4_baseline.json",
    "ruta_fig_confusion": "figuras/fig_matriz_confusion_m4.png",
    "ruta_fig_shap": "figuras/shap_lemas_m4.png",
    "ruta_log": "experimentos/m4_baseline.log",
}

LOGGER = logging.getLogger("m4_baseline")

# Lemas que aparecen como nucleo de citas normativas tras lematizacion.
LEMAS_CITA = {
    # Con tilde (forma dominante de spaCy: articulo 91.784 vs articulo 1.215)
    "artículo",
    "artículos",
    # Sin tilde (variantes residuales)
    "articulo",
    "articulos",
    "ley",
    "leyes",
    "decreto",
    "decretos",
    "acto",
    "legislativo",
    "sentencia",
    "sentencias",
    "auto",
    "numeral",
    "numerales",
    "inciso",
    "incisos",
    "literal",
    "literales",
    "parágrafo",
    "paragrafo",
    "constitución",
    "constitucion",
    "política",  # "politica constitucional" no es cita; se excluye abajo
}
# "politica" se retira: no es nucleo de cita (falso positivo del reviewer).
LEMAS_CITA.discard("política")
# Token [CITA] que reemplaza las secuencias enmascaradas.
TOKEN_CITA = "CITA"
# Numeros romanos REALES (regex estricta; evita falsos como civil/mi/mil).
RE_ROMANO = re.compile(
    r"^(?=.{1,7}$)m{0,4}(cm|cd|d?c{0,3})(xc|xl|l?x{0,3})(ix|iv|v?i{0,3})$",
    re.IGNORECASE,
)
# Numeros arabigos aislados (nucleo de toda cita).
RE_ARABIGO = re.compile(r"^\d{1,4}$")


def es_numero_cita(token: str) -> bool:
    """Determina si un token de lemas puede ser el numero de una cita.

    Args:
        token: Token (posible arabigo o romano).

    Returns:
        True si es arabigo de 1-4 digitos o romano real (regex estricta
        que evita falsos como civil/mi/mil).
    """
    return bool(RE_ARABIGO.match(token) or RE_ROMANO.match(token))
# Prefijos de sentencia citada ya lematizados (t, c, su + numero).
RE_SENT_CITADA = re.compile(r"^(?:t|c|su)$", re.IGNORECASE)


def configurar_logging() -> logging.Logger:
    """Configura el logger del experimento (archivo + consola)."""
    Path(CONFIG["ruta_log"]).parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[
            logging.FileHandler(CONFIG["ruta_log"], mode="w"),
            logging.StreamHandler(),
        ],
    )
    return LOGGER


def normalizar_lemas(texto: str) -> str:
    """Normaliza lemas multi-palabra a un solo token con guion bajo.

    Args:
        texto: Secuencia de lemas separados por espacio.

    Returns:
        Secuencia con lemas multi-palabra unidos por "_".
    """
    return " ".join(tok.replace(" ", "_") for tok in texto.split())


def enmascarar_citas_lemas(texto: str) -> str:
    """Enmascara secuencias de lemas tipicas de citas normativas.

    Correcciones tras auditoria L2 (2026-09-09, ml-reviewer):
    - La lematizacion (is_alpha) elimino los arabigos, pero los ROMANOS
      sobreviven ("ley ii", "articulo xxix"): se enmascaran nucleo+romano.
    - Se anaden nucleos con tilde ("articulo") y plurales, que spaCy emite.
    - Romano con regex estricta (evita falsos civil/mi/mil).
    - Ademas del patron nucleo+numero, se enmascara romano suelto tras
      nucleo aunque haya palabras intermedias no relevantes ("numeral 3 del
      literal b" -> una sola CITA por segmento).

    Args:
        texto: Secuencia de lemas normalizados.

    Returns:
        Secuencia con las citas reemplazadas por CITA.
    """
    tokens = texto.split()
    salida: list[str] = []
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        base = tok.split("_")[0]
        if base in LEMAS_CITA:
            # Consumir el nucleo y todo numero/anexo contiguo.
            j = i + 1
            consumio_numero = False
            while j < len(tokens):
                sig = tokens[j]
                if es_numero_cita(sig):
                    consumio_numero = True
                    j += 1
                elif consumio_numero and sig in {"de", "del", "y", "la", "el", "las", "los"}:
                    # Conectores dentro de series de citas ("articulo 11 y 13").
                    j += 1
                    if j < len(tokens) and es_numero_cita(tokens[j]):
                        continue
                    j -= 1
                    break
                else:
                    break
            if consumio_numero:
                salida.append(TOKEN_CITA)
                i = j
            else:
                salida.append(tok)
                i += 1
        elif RE_SENT_CITADA.match(base) and i + 1 < len(tokens) and es_numero_cita(tokens[i + 1]):
            # Sentencia citada: t/c/su + numero (+ de + ano).
            j = i + 2
            if j < len(tokens) and tokens[j] == "de" and j + 1 < len(tokens) and es_numero_cita(tokens[j + 1]):
                j += 2
            salida.append(TOKEN_CITA)
            i = j
        else:
            salida.append(tok)
            i += 1
    return " ".join(salida)


def cargar_datos() -> pd.DataFrame:
    """Carga y une lemas + etiquetas, excluyendo sin_area_definida.

    Returns:
        DataFrame con id, lemas, area y particiones train/val/test.
    """
    lemas = pq.read_table(CONFIG["ruta_lemas"]).to_pandas()
    etiquetas = pq.read_table(CONFIG["ruta_etiquetas"]).to_pandas()
    df = lemas.merge(etiquetas[["id", "area_primaria", "tipo", "ano"]], on="id")
    n_antes = len(df)
    df = df[df["area_primaria"] != "sin_area_definida"].reset_index(drop=True)
    # Clases con <3 docs no admiten split estratificado 70/15/15 (elecciones
    # tiene 1 doc): se agrupan en otras_areas (documentado en metricas).
    conteo = df["area_primaria"].value_counts()
    raras = conteo[conteo < 3].index.tolist()
    if raras:
        df.loc[df["area_primaria"].isin(raras), "area_primaria"] = "otras_areas"
        LOGGER.info("clases raras (<3 docs) agrupadas en otras_areas: %s", raras)
    df["lemas_norm"] = df["lemas_texto"].map(normalizar_lemas)
    df["lemas_mask"] = df["lemas_norm"].map(enmascarar_citas_lemas)
    LOGGER.info(
        "datos: %d filas (%d excluidas sin_area), %d clases",
        len(df),
        n_antes - len(df),
        df["area_primaria"].nunique(),
    )
    return df


def crear_splits(df: pd.DataFrame) -> pd.DataFrame:
    """Crea el split estratificado 70/15/15 UNA VEZ y lo persiste.

    Args:
        df: DataFrame con lemas y area.

    Returns:
        DataFrame con columna particion (train/val/test).
    """
    ruta = Path(CONFIG["ruta_splits"])
    if ruta.exists():
        splits = pq.read_table(ruta).to_pandas()
        df = df.merge(splits, on="id")
        LOGGER.info("splits existentes reutilizados: %s", splits["particion"].value_counts().to_dict())
        return df
    _, resto = train_test_split(
        df["id"],
        test_size=0.30,
        random_state=CONFIG["semilla"],
        stratify=df["area_primaria"],
    )
    # Clases con 1 doc en resto rompen el split estratificado val/test:
    # se asignan manualmente a val y se estratifica el resto.
    conteo_resto = df.loc[resto.index, "area_primaria"].value_counts()
    unicas = conteo_resto[conteo_resto == 1].index
    ids_unicas = resto[df.loc[resto.index, "area_primaria"].isin(unicas)]
    resto_est = resto[~resto.isin(ids_unicas)]
    if len(ids_unicas):
        LOGGER.info(
            "clases con 1 doc en resto asignadas a val: %s",
            df.loc[ids_unicas.index, "area_primaria"].tolist(),
        )
    val, test = train_test_split(
        resto_est,
        test_size=0.50,
        random_state=CONFIG["semilla"],
        stratify=df.loc[resto_est.index, "area_primaria"],
    )
    val = pd.Index(list(val) + list(ids_unicas))
    df["particion"] = "train"
    df.loc[df["id"].isin(val), "particion"] = "val"
    df.loc[df["id"].isin(test), "particion"] = "test"
    pq.write_table(
        pa.Table.from_pandas(df[["id", "particion"]]),
        ruta,
    )
    LOGGER.info("splits creados: %s", df["particion"].value_counts().to_dict())
    return df


def vectorizar(df: pd.DataFrame, columna: str) -> dict:
    """Vectoriza un escenario con TF-IDF sobre la columna dada.

    Args:
        df: DataFrame con particiones.
        columna: lemas_norm (completo) o lemas_mask (enmascarado).

    Returns:
        Dict con matrices X_train/X_val/X_test, vectorizador y clases.
    """
    vec = TfidfVectorizer(
        min_df=CONFIG["min_df"],
        max_features=CONFIG["max_features"],
        ngram_range=CONFIG["ngram"],
        sublinear_tf=True,
    )
    tr = df[df["particion"] == "train"]
    va = df[df["particion"] == "val"]
    te = df[df["particion"] == "test"]
    X_train = vec.fit_transform(tr[columna])
    X_val = vec.transform(va[columna])
    X_test = vec.transform(te[columna])
    LOGGER.info(
        "vectorizado %s: %d features (train %d, val %d, test %d)",
        columna,
        len(vec.get_feature_names_out()),
        X_train.shape[0],
        X_val.shape[0],
        X_test.shape[0],
    )
    return {
        "X_train": X_train,
        "X_val": X_val,
        "X_test": X_test,
        "vec": vec,
        "y_train": tr["area_primaria"].values,
        "y_val": va["area_primaria"].values,
        "y_test": te["area_primaria"].values,
    }


def entrenar_linearsvc(datos: dict) -> Pipeline:
    """Entrena LinearSVC sobre TF-IDF (baseline rapido).

    Args:
        datos: Dict de vectorizar().

    Returns:
        Pipeline ajustado.
    """
    modelo = LinearSVC(C=1.0, random_state=CONFIG["semilla"], dual="auto")
    modelo.fit(datos["X_train"], datos["y_train"])
    return modelo


def entrenar_logreg_optuna(datos: dict) -> LogisticRegression:
    """Optimiza LogisticRegression multinomial con Optuna (macro-F1 en val).

    Nota de diseño (2026-09-08): LightGBM sobre TF-IDF disperso de 100k
    features provoco muertes silenciosas por presion de RAM en esta
    maquina compartida (3 corridas) y es suboptimo para texto (los modelos
    lineales dominan en clasificacion de texto disperso). Se sustituye
    por LogisticRegression multinomial optimizada con Optuna: misma
    familia de busqueda de hiperparametros, huella de RAM minima.

    Args:
        datos: Dict de vectorizar().

    Returns:
        Mejor LogisticRegression reentrenada en train+val.
    """
    optuna.logging.set_verbosity(optuna.logging.WARNING)

    def objetivo(trial: optuna.Trial) -> float:
        params = {
            "C": trial.suggest_float("C", 1e-2, 1e2, log=True),
            "penalty": trial.suggest_categorical("penalty", ["l2"]),
            "solver": "lbfgs",
            "max_iter": 600,
            "random_state": CONFIG["semilla"],
        }
        modelo = LogisticRegression(**params)
        modelo.fit(datos["X_train"], datos["y_train"])
        y_pred = modelo.predict(datos["X_val"])
        return f1_score(datos["y_val"], y_pred, average="macro")

    estudio = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=CONFIG["semilla"]))
    estudio.optimize(objetivo, n_trials=CONFIG["optuna_trials"], show_progress_bar=False)
    LOGGER.info("optuna: mejor macro-F1 val=%.4f params=%s", estudio.best_value, estudio.best_params)

    # Reentrenar la mejor configuracion en train+val para evaluar en test.
    X_tv = vstack([datos["X_train"], datos["X_val"]]).tocsr()
    y_tv = np.concatenate([datos["y_train"], datos["y_val"]])
    modelo = LogisticRegression(
        C=estudio.best_params["C"],
        penalty="l2",
        solver="lbfgs",
        max_iter=600,
        random_state=CONFIG["semilla"],
    )
    modelo.fit(X_tv, y_tv)
    return modelo


def evaluar(modelo, datos: dict, es_logreg: bool = False) -> dict:
    """Evalua un modelo en test y devuelve metricas + predicciones.

    Args:
        modelo: Modelo ajustado (LinearSVC o LGBM).
        datos: Dict de vectorizar().
        es_logreg: True si el modelo es LogisticRegression (no necesario: predict directo).

    Returns:
        Dict con macro_f1, accuracy, f1_por_clase, y_pred.
    """
    y_pred = modelo.predict(datos["X_test"])
    return {
        "macro_f1": float(f1_score(datos["y_test"], y_pred, average="macro")),
        "accuracy": float(accuracy_score(datos["y_test"], y_pred)),
        "f1_por_clase": classification_report(
            datos["y_test"], y_pred, output_dict=True, zero_division=0
        ),
        "y_pred": y_pred,
    }


def figura_confusion(y_true, y_pred, ruta: str) -> None:
    """Genera la matriz de confusion de las 8 clases mas frecuentes.

    Args:
        y_true: Etiquetas reales.
        y_pred: Predicciones.
        ruta: Ruta del PNG a guardar.
    """
    top = pd.Series(y_true).value_counts().head(8).index.tolist()
    mask = pd.Series(y_true).isin(top)
    cm = confusion_matrix(
        pd.Series(y_true)[mask], pd.Series(y_pred)[mask], labels=top, normalize="true"
    )
    fig, ax = plt.subplots(figsize=(10, 8))
    im = ax.imshow(cm, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(len(top)))
    ax.set_xticklabels(top, rotation=45, ha="right", fontsize=8)
    ax.set_yticks(range(len(top)))
    ax.set_yticklabels(top, fontsize=8)
    for i in range(len(top)):
        for j in range(len(top)):
            ax.text(j, i, f"{cm[i, j]:.2f}", ha="center", va="center", fontsize=7)
    fig.colorbar(im)
    ax.set_title("Matriz de confusion M4 (top-8 clases, normalizada)")
    ax.set_xlabel("Prediccion")
    ax.set_ylabel("Real")
    fig.tight_layout()
    fig.savefig(ruta, dpi=150)
    plt.close(fig)


def shap_lineal(modelo, datos: dict, ruta: str) -> dict:
    """Importancia de lemas del modelo lineal (pesos absolutos medios).

    Nota: para LinearSVC se usa la magnitud media de los coeficientes por
    clase (proxy SHAP lineal exacto para modelos lineales).

    Args:
        modelo: LinearSVC ajustado.
        datos: Dict de vectorizar().
        ruta: Ruta del PNG.

    Returns:
        Dict con top-20 lemas por importancia global.
    """
    nombres = datos["vec"].get_feature_names_out()
    importancias = np.abs(modelo.coef_).mean(axis=0)
    orden = np.argsort(importancias)[::-1][:20]
    top = {str(nombres[i]): float(importancias[i]) for i in orden}
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.barh(
        [str(nombres[i]) for i in orden][::-1],
        importancias[orden][::-1],
        color="#2F75B5",
    )
    ax.set_title("Top-20 lemas por importancia (LinearSVC, |coef| medio)")
    ax.set_xlabel("Importancia media")
    fig.tight_layout()
    fig.savefig(ruta, dpi=150)
    plt.close(fig)
    return top


def main() -> None:
    """Ejecuta el pipeline completo del baseline clasico M4."""
    t0 = time.time()
    LOGGER.info("inicio baseline M4")
    df = cargar_datos()
    df = crear_splits(df)

    resultados: dict = {"fecha": pd.Timestamp.now().isoformat(), "config": {k: v for k, v in CONFIG.items() if k != "ruta_log"}}
    mejor = {"macro_f1": 0.0}

    for escenario, columna in [("completo", "lemas_norm"), ("enmascarado", "lemas_mask")]:
        datos = vectorizar(df, columna)
        # LinearSVC.
        svc = entrenar_linearsvc(datos)
        m_svc = evaluar(svc, datos)
        LOGGER.info("[%s] LinearSVC macro-F1 test=%.4f acc=%.4f", escenario, m_svc["macro_f1"], m_svc["accuracy"])
        # LogisticRegression + Optuna (sustituye LightGBM: ver docstring).
        logreg = entrenar_logreg_optuna(datos)
        m_lgr = evaluar(logreg, datos)
        LOGGER.info("[%s] LogReg macro-F1 test=%.4f acc=%.4f", escenario, m_lgr["macro_f1"], m_lgr["accuracy"])

        resultados[escenario] = {
            "linearsvc": {"macro_f1": m_svc["macro_f1"], "accuracy": m_svc["accuracy"]},
            "logreg": {"macro_f1": m_lgr["macro_f1"], "accuracy": m_lgr["accuracy"]},
        }
        # Rastrear el mejor modelo global (para figuras/guardado).
        if m_svc["macro_f1"] > mejor["macro_f1"]:
            mejor = {
                "macro_f1": m_svc["macro_f1"],
                "modelo": svc,
                "datos": datos,
                "y_pred": m_svc["y_pred"],
                "nombre": f"linearsvc_{escenario}",
            }
        if m_lgr["macro_f1"] > mejor["macro_f1"]:
            mejor = {
                "macro_f1": m_lgr["macro_f1"],
                "modelo": logreg,
                "datos": datos,
                "y_pred": m_lgr["y_pred"],
                "nombre": f"logreg_{escenario}",
            }

    # Gap de leakage (ADR-2): diferencia entre escenarios por modelo.
    resultados["gap_leakage"] = {
        "linearsvc": resultados["completo"]["linearsvc"]["macro_f1"]
        - resultados["enmascarado"]["linearsvc"]["macro_f1"],
        "logreg": resultados["completo"]["logreg"]["macro_f1"]
        - resultados["enmascarado"]["logreg"]["macro_f1"],
    }
    LOGGER.info("gap leakage: %s", resultados["gap_leakage"])

    # Figuras y guardado del mejor.
    datos_mejor = mejor["datos"]
    figura_confusion(datos_mejor["y_test"], mejor["y_pred"], CONFIG["ruta_fig_confusion"])
    # Importancias para el mejor modelo SEA CUAL SEA (ambos son lineales:
    # LinearSVC y LogisticRegression exponen .coef_).
    resultados["shap_top20"] = shap_lineal(mejor["modelo"], datos_mejor, CONFIG["ruta_fig_shap"])
    resultados["nota_shap"] = (
        "Importancias |coef| medio del mejor modelo lineal (equivalente SHAP "
        "lineal); generado por el propio script (trazable)."
    )
    Path(CONFIG["dir_modelo"]).mkdir(parents=True, exist_ok=True)
    joblib.dump(mejor["modelo"], f"{CONFIG['dir_modelo']}/{mejor['nombre']}.joblib")
    joblib.dump(datos_mejor["vec"], f"{CONFIG['dir_modelo']}/tfidf_{mejor['nombre'].split('_', 1)[1]}.joblib")

    resultados["mejor_modelo"] = {"nombre": mejor["nombre"], "macro_f1": mejor["macro_f1"]}
    resultados["tiempo_total_seg"] = time.time() - t0
    Path(CONFIG["ruta_metricas"]).parent.mkdir(parents=True, exist_ok=True)
    with open(CONFIG["ruta_metricas"], "w", encoding="utf-8") as f:
        json.dump(resultados, f, ensure_ascii=False, indent=2, default=str)
    LOGGER.info("fin en %.1f s; mejor=%s macro-F1=%.4f", resultados["tiempo_total_seg"], mejor["nombre"], mejor["macro_f1"])


if __name__ == "__main__":
    configurar_logging()
    main()
