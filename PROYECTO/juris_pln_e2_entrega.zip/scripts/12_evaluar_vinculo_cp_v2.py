"""12_evaluar_vinculo_cp_v2.py
Fecha: 2026-09-08
Descripcion: Recalibracion (Fase K-2) del benchmark M7 del vinculo
    sentencia -> articulos de la Constitucion Politica sobre weak labels de
    M2 (data/entidades_sentencias.parquet, arts_cp). Corrige las causas
    diagnosticadas del v1 (scripts/11_evaluar_vinculo_cp.py) manteniendo el
    protocolo temporal de ADR-5 (P@k, R@k, F1@k, MRR; global, por anio y por
    periodo). Mejoras pre-registradas:
    (1) indice por PASAJES: cada articulo se segmenta en pasajes de
        oraciones (<= CONFIG['pasaje_max_palabras'] palabras) y el score del
        articulo es el MAXIMO sobre sus pasajes (BM25 por pasajes, SOTA
        DoSSIER/COLIEE 2021; Fink 2023);
    (2) COBERTURA COMPLETA con MAX-POOLING por chunks: la hipotesis inicial
        de recortar la query a la ventana inicial (considerandos) fue
        REFUTADA con evidencia sobre la muestra v2: la primera cita de un
        articulo etiquetado aparece a mediana en el 41% del texto (solo
        29.5% de casos la tienen en el primer cuarto) y el sweep de
        calibracion mostro mejora monotona con la cobertura (ventana 3000
        chars F1 0.127 vs texto completo 0.204 en BM25). Por ello la query
        es el texto completo dividido en chunks (BM25: chunks de
        CONFIG['chunk_bm25_chars'] caracteres con solape; E5: chunks de 512
        tokens, ADR-3) y el score del articulo es el MAXIMO entre chunks
        (max-pooling: un articulo citado en cualquier parte del texto
        puntua);
    (3) tokenizacion BM25 con STOPWORDS JURIDICAS (terminos procesales que
        no discriminan entre articulos) y BIGRAMAS de las colocaciones LLR
        ganadoras del EDA de PRIMERA ENTREGA (resultados/eda_extendido/
        colocaciones.csv, top-20 LLR; se excluyen nombres propios, fechas
        y conectivos procesales, exclusion documentada en CONFIG); el
        ablation sobre la muestra v2 confirma que la tokenizacion mejorada
        supera a la simple en F1@5 (0.218 vs 0.206 con chunk 800);
    (4) E5-multilingual-base en GPU (pooling mean-tokens por chunk, score
        del articulo = MAX coseno sobre sus pasajes y chunks de query);
    (5) muestra ampliada a 3 sentencias/anio (90 casos, semilla 42) con
        cupos proporcionales al tipo dentro de cada anio;
    (6) estrategia HIBRIDA pre-registrada: 0.5*BM25 + 0.5*E5 con
        normalizacion min-max por caso.
    La estrategia cita-exacta (regex M2) se mantiene como referencia
    circular por construccion y se reporta por separado.
Estado del arte aplicado: BM25 por pasajes con agregacion max, max-pooling
    de chunks de query (cobertura completa), hibrido lexico-denso con
    normalizacion min-max por consulta (pre-registrado 0.5/0.5), E5
    zero-shot para deriva temporal (ADR-3, ADR-6), protocolo temporal de
    ADR-5 con P@k, R@k, F1@k y MRR.
"""

import importlib.util
import itertools
import json
import random
import re
import sys
import time
import traceback
import unicodedata
from datetime import datetime, timezone
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pyarrow.dataset as pqds
import torch
from rank_bm25 import BM25Okapi

CONFIG = {
    "semilla": 42,
    "k": 5,
    "ano_min": 1992,
    "ano_max": 2021,
    "muestra_por_ano": 3,
    # --- cobertura de query (mejora 2) ---
    "ventana_query_chars": 10**9,
    "chunk_bm25_chars": 800,
    "solape_bm25_chars": 200,
    # --- pasajes por articulo (mejora 1) ---
    "pasaje_max_palabras": 120,
    "agregacion_pasajes": "max",
    "agregacion_chunks_bm25": "max",
    "agregacion_chunks_e5": "max",
    # --- E5 (mejora 4) ---
    "tamano_chunk": 512,
    "solape_chunk": 64,
    "reserva_prefijo_tokens": 4,
    "prefijo_query": "query: ",
    "prefijo_pasaje": "passage: ",
    "modelo_e5": "intfloat/multilingual-e5-base",
    "batch_embedding": 32,
    "batch_embedding_oom": 16,
    "vram_minima_gb": 2.0,
    # --- hibrido (mejora 6, pre-registrado) ---
    "pesos_hibrido": {"bm25": 0.5, "e5": 0.5},
    # --- cita exacta (referencia circular) ---
    "ventana_cp": 60,
    # --- rutas ---
    "ruta_corpus": "data/corpus_sentencias.parquet",
    "ruta_entidades": "data/entidades_sentencias.parquet",
    "ruta_constitucion": "data/constitucion_articulos.parquet",
    "ruta_script_m2": "scripts/03_extraccion_entidades.py",
    "ruta_benchmark_v1": "resultados/vinculo_cp_benchmark.json",
    "ruta_benchmark": "resultados/vinculo_cp_benchmark_v2.json",
    "ruta_por_ano": "resultados/vinculo_cp_por_ano_v2.csv",
    "ruta_figura": "figuras/deriva_retrieval_v2.png",
    "periodos": [
        ("1992-2001", 1992, 2001),
        ("2002-2011", 2002, 2011),
        ("2012-2021", 2012, 2021),
    ],
    "estrategias": ["cita_exacta", "bm25", "e5", "hibrido"],
}

# Stopwords juridicas (mejora 3): terminos procesales de encabezado y de
# citas que aparecen en casi todas las sentencias y no discriminan entre
# articulos de la CP. Lista corta y conservadora, documentada; los bigramas
# compuestos (con "_") nunca se filtran.
CONFIG["stopwords_juridicas"] = frozenset(
    {
        "articulo", "articulos", "ley", "leyes", "numeral", "numerales",
        "inciso", "incisos", "parrafo", "parrafos", "literal", "literales",
        "caso", "casos", "sentencia", "sentencias", "expediente", "bogota",
        "honorable", "magistrado", "magistrados", "ponente", "secretaria",
        "general", "demanda", "demandas", "demandado", "demandados",
        "demandada", "demandadas", "demandante", "demandantes", "dos",
        "mil", "senor", "senora", "senores",
    }
)

# Bigramas LLR ganadores del EDA de PRIMERA ENTREGA (mejora 3): top-20 de
# resultados/eda_extendido/colocaciones.csv (medida llr). Exclusiones
# documentadas: "dos mil" (fecha), "toda vez" y "caso concreto"
# (conectivos procesales), "cepeda espinosa", "jose cepeda" y
# "magistrado ponente" (nombres propios). Quedan 14 colocaciones
# sustantivas del dominio constitucional.
CONFIG["bigramas_llr"] = frozenset(
    {
        ("derechos", "fundamentales"),
        ("corte", "constitucional"),
        ("seguridad", "social"),
        ("constitucion", "politica"),
        ("debido", "proceso"),
        ("derecho", "fundamental"),
        ("minimo", "vital"),
        ("primera", "instancia"),
        ("perjuicio", "irremediable"),
        ("cosa", "juzgada"),
        ("derechos", "humanos"),
        ("corte", "suprema"),
        ("tribunal", "superior"),
        ("segunda", "instancia"),
    }
)

ROOT = Path(__file__).resolve().parent.parent

MEDIDAS = ("p_at_k", "r_at_k", "f1_at_k", "mrr")

# Claves de CONFIG con rutas relativas a la raiz del proyecto; se resuelven
# contra ROOT al inicio de main() para que el script corra desde cualquier
# directorio de trabajo.
RUTAS_RELATIVAS = (
    "ruta_corpus",
    "ruta_entidades",
    "ruta_constitucion",
    "ruta_script_m2",
    "ruta_benchmark_v1",
    "ruta_benchmark",
    "ruta_por_ano",
    "ruta_figura",
)


def resolver_rutas() -> None:
    """Convierte las rutas relativas de CONFIG en absolutas contra ROOT.

    Permite ejecutar el script desde cualquier directorio de trabajo sin
    depender del CWD (el v1 asumia workdir = raiz del proyecto).
    """
    for clave in RUTAS_RELATIVAS:
        ruta = Path(CONFIG[clave])
        if not ruta.is_absolute():
            CONFIG[clave] = str(ROOT / ruta)


# ===== SECCION 1: utilidades base =====
def configurar_semillas(semilla: int) -> None:
    """Fija semillas de aleatoriedad y hilos de torch.

    Args:
        semilla: Valor entero de semilla.
    """
    random.seed(semilla)
    np.random.seed(semilla)
    torch.manual_seed(semilla)
    torch.set_num_threads(32)


def elegir_dispositivo() -> str:
    """Elige GPU solo si hay VRAM libre suficiente para E5.

    La maquina comparte la GPU con procesos externos (p. ej. llama-server).
    Si la memoria libre es menor que CONFIG['vram_minima_gb'] se degrada a
    CPU y se documenta en el log; no se cambia de modelo ni de metodologia.

    Returns:
        "cuda" si hay >= 2 GiB libres y torch la ve disponible; si no, "cpu".
    """
    if not torch.cuda.is_available():
        return "cpu"
    libre, _ = torch.cuda.mem_get_info()
    minimo = int(CONFIG["vram_minima_gb"] * 1024**3)
    if libre < minimo:
        print(
            "[aviso] VRAM libre insuficiente para E5 "
            f"({libre / 1024**3:.1f} GiB < {CONFIG['vram_minima_gb']} GiB); "
            "se ejecuta E5 en CPU (GPU ocupada por procesos externos)"
        )
        return "cpu"
    return "cuda"


def normalizar_sin_tildes(texto: str) -> str:
    """Convierte un texto a minusculas y sin diacriticos.

    Args:
        texto: Texto original.

    Returns:
        Texto normalizado.
    """
    sin_tildes = "".join(
        c for c in unicodedata.normalize("NFD", texto) if not unicodedata.combining(c)
    )
    return sin_tildes.lower()


def tokenizar(texto: str) -> list[str]:
    """Tokeniza para BM25: unigramas sin stopwords juridicas + bigramas LLR.

    Los bigramas se detectan sobre la secuencia completa de unigramas (sin
    filtrar) y se anaden como tokens compuestos "a_b"; despues se filtran
    los unigramas procesales. Asi "corte constitucional" sobrevive como
    bigrama aunque "corte" no este en la lista de stopwords.

    Args:
        texto: Texto a tokenizar.

    Returns:
        Lista de tokens (unigramas utiles + bigramas compuestos).
    """
    tokens = re.findall(r"[a-z0-9]+", normalizar_sin_tildes(texto))
    bigramas = [
        f"{a}_{b}"
        for a, b in itertools.pairwise(tokens)
        if (a, b) in CONFIG["bigramas_llr"]
    ]
    unigramas = [t for t in tokens if t not in CONFIG["stopwords_juridicas"]]
    return unigramas + bigramas


def leer_filas_por_id(ruta: str, columnas: list[str], ids: list[str]) -> pd.DataFrame:
    """Lee solo las filas con los ids dados de un parquet (posible particion).

    Usa pyarrow.dataset con filtro pushdown para no materializar en RAM el
    corpus completo mientras corre el job de lematizacion (05_lematizacion).

    Args:
        ruta: Ruta del parquet (archivo o directorio particionado).
        columnas: Columnas a leer.
        ids: Lista de ids (strings) a conservar.

    Returns:
        DataFrame con las filas cuyos ids estan en la lista.
    """
    dataset = pqds.dataset(ruta, format="parquet")
    tabla = dataset.to_table(
        columns=columnas, filter=pqds.field("id").isin(ids)
    )
    return tabla.to_pandas()


def importar_extraccion_m2() -> object:
    """Importa el modulo 03_extraccion_entidades.py (M2) por importlib.

    El nombre del archivo empieza por digito y no admite import estandar; se
    carga con spec para reutilizar extraer_arts_cp sin duplicar logica.

    Returns:
        Modulo M2 con la funcion extraer_arts_cp.
    """
    ruta = ROOT / CONFIG["ruta_script_m2"]
    spec = importlib.util.spec_from_file_location("extraccion_m2", ruta)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"No se pudo cargar el modulo M2: {ruta}")
    modulo = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(modulo)
    return modulo


# ===== SECCION 2: muestra temporal 3/anio estratificada (mejora 5) =====
def cuotas_proporcionales(conteo: dict[str, int], cupos: int) -> dict[str, int]:
    """Reparte cupos entre tipos proporcionalmente (mayor resto, determinista).

    Args:
        conteo: Dict {tipo: numero de sentencias labeled del anio}.
        cupos: Total de cupos a repartir (CONFIG['muestra_por_ano']).

    Returns:
        Dict {tipo: cupos enteros} con suma <= cupos.
    """
    total = sum(conteo.values())
    if total <= 0 or cupos <= 0:
        return {tipo: 0 for tipo in conteo}
    crudo = {tipo: cupos * n / total for tipo, n in conteo.items()}
    base = {tipo: int(crudo[tipo]) for tipo in conteo}
    faltante = cupos - sum(base.values())
    orden = sorted(conteo, key=lambda t: (-(crudo[t] - base[t]), t))
    for tipo in orden[:faltante]:
        base[tipo] += 1
    return base


def muestrear_anio(grupo: pd.DataFrame, cupos: dict[str, int], rng: random.Random) -> pd.DataFrame:
    """Elige sentencias de un anio segun los cupos por tipo, con relleno.

    Si un tipo no alcanza su cuota, el deficit se rellena muestreando entre
    las filas restantes del anio (cualquier tipo) para no perder casos.

    Args:
        grupo: Filas labeled de un anio (columnas id, tipo, ano).
        cupos: Dict {tipo: cuota} calculado por cuotas_proporcionales.
        rng: Generador aleatorio con semilla fija.

    Returns:
        DataFrame con las filas elegidas del anio.
    """
    indices_elegidos: list[int] = []
    for tipo in sorted(cupos):
        subgrupo = grupo[grupo["tipo"] == tipo].sort_values("id")
        cuota = min(cupos[tipo], len(subgrupo))
        if cuota <= 0:
            continue
        posiciones = rng.sample(range(len(subgrupo)), cuota)
        indices_elegidos.extend(subgrupo.iloc[posiciones].index.tolist())
    faltan = sum(cupos.values()) - len(indices_elegidos)
    if faltan > 0:
        resto = grupo[~grupo.index.isin(indices_elegidos)].sort_values("id")
        if not resto.empty:
            cuota = min(faltan, len(resto))
            posiciones = rng.sample(range(len(resto)), cuota)
            indices_elegidos.extend(resto.iloc[posiciones].index.tolist())
    return grupo.loc[sorted(indices_elegidos)]


def cargar_muestra_temporal(marco: pd.DataFrame) -> pd.DataFrame:
    """Selecciona 3 sentencias por anio (1992-2021) con semilla fija.

    Dentro de cada anio los cupos se reparten proporcionalmente al tipo
    (T/C/SU) con el metodo del mayor resto y el muestreo es determinista
    (orden por id, rng con semilla 42, tipos en orden alfabetico).

    Args:
        marco: DataFrame con columnas id, tipo, ano y labeled (bool).

    Returns:
        DataFrame con <= 90 filas (3/anio) ordenadas por (ano, id).
    """
    rng = random.Random(CONFIG["semilla"])
    filas = []
    etiquetadas = marco[marco["labeled"]]
    for anio in range(CONFIG["ano_min"], CONFIG["ano_max"] + 1):
        grupo = etiquetadas[etiquetadas["ano"] == anio]
        if grupo.empty:
            continue
        conteo = grupo["tipo"].value_counts().to_dict()
        cupos = cuotas_proporcionales(conteo, CONFIG["muestra_por_ano"])
        filas.append(muestrear_anio(grupo, cupos, rng))
    muestra = pd.concat(filas, ignore_index=True) if filas else pd.DataFrame()
    return muestra.sort_values(["ano", "id"]).reset_index(drop=True)


# ===== SECCION 3: pasajes de la Constitucion (mejora 1) =====
def dividir_pasajes(texto: str, max_palabras: int) -> list[str]:
    """Segmenta un articulo en pasajes de oraciones completas.

    El parquet de la Constitucion no conserva saltos de parrafo, por lo que
    la segmentacion es por oraciones (split tras punto) agrupadas hasta
    max_palabras; una oracion mas larga que el limite queda intacta como
    pasaje propio (E5 la trocea internamente por tokens si hace falta).

    Args:
        texto: Texto del articulo.
        max_palabras: Limite de palabras por pasaje.

    Returns:
        Lista de pasajes (>= 1 para todo texto no vacio).
    """
    oraciones = [o.strip() for o in re.split(r"(?<=\.)\s+", texto) if o.strip()]
    pasajes: list[str] = []
    actual: list[str] = []
    palabras = 0
    for oracion in oraciones:
        largo = len(oracion.split())
        if palabras + largo > max_palabras and actual:
            pasajes.append(" ".join(actual))
            actual, palabras = [], 0
        actual.append(oracion)
        palabras += largo
    if actual:
        pasajes.append(" ".join(actual))
    return pasajes if pasajes else ([texto.strip()] if texto.strip() else [])


def preparar_pasajes_constitucion() -> tuple[pd.DataFrame, list[str], list[np.ndarray]]:
    """Carga los articulos y los segmenta en pasajes para el indice.

    Returns:
        Tupla (pasajes, canones, grupos_indices):
        - pasajes: DataFrame con columnas canon, texto y tokens (un pasaje
          por fila, en orden de articulo);
        - canones: Lista de canones de articulos (497, alineada a grupos);
        - grupos_indices: Lista (por articulo, mismo orden que canones) de
          arrays con las posiciones de sus pasajes en el DataFrame.
    """
    articulos = pd.read_parquet(CONFIG["ruta_constitucion"])
    canones = articulos["numero"].astype(str).tolist()
    textos = articulos["texto"].fillna("").astype(str).tolist()
    filas = []
    grupos_indices = []
    posicion = 0
    for canon, texto in zip(canones, textos, strict=True):
        trozos = dividir_pasajes(texto, CONFIG["pasaje_max_palabras"])
        indices = []
        for trozo in trozos:
            filas.append({"canon": canon, "texto": trozo})
            indices.append(posicion)
            posicion += 1
        grupos_indices.append(np.asarray(indices, dtype=int))
    pasajes = pd.DataFrame(filas)
    pasajes["tokens"] = pasajes["texto"].apply(tokenizar)
    return pasajes, canones, grupos_indices


# ===== SECCION 4: metricas de retrieval (protocolo ADR-5) =====
def metricas_ranking(relevantes: list[str], ranking: list[str], k: int) -> dict:
    """Calcula P@k, R@k, F1@k y MRR de un ranking frente a los relevantes.

    Args:
        relevantes: Canones de articulos relevantes (weak labels).
        ranking: Canones ordenados por el retrieval (mejor primero).
        k: Profundidad para P@k, R@k y F1@k.

    Returns:
        Dict con p_at_k, r_at_k, f1_at_k y mrr.
    """
    rel = set(relevantes)
    top = ranking[:k]
    recuperados = sum(1 for x in top if x in rel)
    p = recuperados / k
    r = recuperados / len(rel) if rel else 0.0
    f1 = 2 * p * r / (p + r) if p + r > 0 else 0.0
    mrr = 0.0
    for pos, canon in enumerate(ranking, start=1):
        if canon in rel:
            mrr = 1.0 / pos
            break
    return {"p_at_k": p, "r_at_k": r, "f1_at_k": f1, "mrr": mrr}


def promediar_metricas(metricas: list[dict]) -> dict:
    """Promedia las cuatro medidas sobre varios casos de retrieval.

    Args:
        metricas: Lista de dicts de metricas_ranking.

    Returns:
        Dict con las medias de p_at_k, r_at_k, f1_at_k y mrr.
    """
    return {
        medida: float(np.mean([m[medida] for m in metricas])) for medida in MEDIDAS
    }


def asignar_periodo(anio: int) -> str:
    """Asigna un anio a su periodo cronologico de CONFIG.

    Args:
        anio: Anio de la sentencia.

    Returns:
        Nombre del periodo (p. ej. "1992-2001") que contiene el anio.
    """
    for nombre, inicio, fin in CONFIG["periodos"]:
        if inicio <= anio <= fin:
            return nombre
    return "desconocido"


def metricas_por_caso(casos: list[dict]) -> pd.DataFrame:
    """Evalua las cuatro estrategias sobre cada caso de la muestra.

    Args:
        casos: Lista de dicts con id, ano, arts y rankings por estrategia.

    Returns:
        DataFrame largo con una fila por (id, estrategia) y sus medidas.
    """
    filas = []
    for caso in casos:
        relevantes = caso["arts"]
        for estrategia in CONFIG["estrategias"]:
            medidas = metricas_ranking(
                relevantes, caso["rankings"][estrategia], CONFIG["k"]
            )
            filas.append(
                {
                    "id": caso["id"],
                    "ano": caso["ano"],
                    "estrategia": estrategia,
                    "n_relevantes": len(relevantes),
                    **medidas,
                }
            )
    return pd.DataFrame(filas)


def agregar_por_periodo(por_caso: pd.DataFrame) -> dict:
    """Agrupa metricas por periodo cronologico (ADR-5).

    Args:
        por_caso: DataFrame con columnas ano, estrategia y las medidas.

    Returns:
        Dict anidado {periodo: {estrategia: {medidas medias}}}.
    """
    resultado = {}
    por_caso = por_caso.copy()
    por_caso["periodo"] = por_caso["ano"].apply(asignar_periodo)
    for nombre_periodo, _, _ in CONFIG["periodos"]:
        grupo = por_caso[por_caso["periodo"] == nombre_periodo]
        resultado[nombre_periodo] = {}
        for estrategia in CONFIG["estrategias"]:
            filas = grupo[grupo["estrategia"] == estrategia]
            resultado[nombre_periodo][estrategia] = {
                medida: float(filas[medida].mean()) for medida in MEDIDAS
            }
    return resultado


# ===== SECCION 5: estrategia BM25 por pasajes con query en chunks =====
def construir_indice_bm25(pasajes: pd.DataFrame) -> BM25Okapi:
    """Construye el indice BM25 sobre los PASAJES de los articulos.

    Args:
        pasajes: DataFrame con la columna tokens (un pasaje por fila).

    Returns:
        Indice BM25Okapi listo para consultas.
    """
    return BM25Okapi(pasajes["tokens"].tolist())


def chunks_query(texto: str) -> list[str]:
    """Divide la query en chunks de caracteres con solape (cobertura total).

    La ventana es el texto completo (CONFIG['ventana_query_chars'] = inf
    practico): la evidencia de calibracion refuto la ventana inicial corta
    (las citas aparecen a lo largo de todo el texto).

    Args:
        texto: Texto limpio de la sentencia.

    Returns:
        Lista de chunks (>= 1 si el texto no esta vacio).
    """
    ventana = texto[: CONFIG["ventana_query_chars"]]
    chunks: list[str] = []
    inicio = 0
    while inicio < len(ventana):
        fin = min(inicio + CONFIG["chunk_bm25_chars"], len(ventana))
        chunks.append(ventana[inicio:fin])
        if fin >= len(ventana):
            break
        inicio = fin - CONFIG["solape_bm25_chars"]
    return chunks


def scores_bm25_caso(
    indice: BM25Okapi, grupos_indices: list[np.ndarray], canones: list[str], chunks: list[str]
) -> np.ndarray:
    """Scores BM25 por articulo: max sobre (chunks de query x pasajes).

    Por cada chunk de la query se puntuan todos los pasajes; el score del
    pasaje es el maximo entre chunks (CONFIG['agregacion_chunks_bm25']) y el
    del articulo el maximo entre sus pasajes (CONFIG['agregacion_pasajes']).

    Args:
        indice: Indice BM25Okapi sobre pasajes.
        grupos_indices: Arrays de posiciones de pasajes por articulo.
        canones: Canones alineados con grupos_indices.
        chunks: Chunks de la ventana de query.

    Returns:
        Array (n_articulos,) de scores alineado con canones.
    """
    n_pasajes = indice.corpus_size
    max_pasajes = np.zeros(n_pasajes, dtype=np.float64)
    for chunk in chunks:
        tokens = tokenizar(chunk)
        if not tokens:
            continue
        np.maximum(max_pasajes, indice.get_scores(tokens), out=max_pasajes)
    scores = np.zeros(len(canones), dtype=np.float64)
    for i, indices in enumerate(grupos_indices):
        scores[i] = max_pasajes[indices].max()
    return scores


def ranking_desde_scores(scores: np.ndarray, canones: list[str]) -> list[str]:
    """Ordena los canones por score descendente (empates estables).

    Args:
        scores: Array (n_articulos,) de scores.
        canones: Canones alineados con scores.

    Returns:
        Canones ordenados por score descendente.
    """
    orden = np.argsort(-scores, kind="stable")
    return [canones[i] for i in orden]


# ===== SECCION 6: estrategia E5-multilingual por pasajes (GPU) =====
def chunkear_texto(texto: str, tokenizer: object) -> list[str]:
    """Divide un texto en chunks de <=512 tokens con solape (ADR-3).

    Reserva CONFIG['reserva_prefijo_tokens'] tokens para el prefijo
    "query: "/"passage: " que se anade al codificar.

    Args:
        texto: Texto crudo largo (ventana de query o pasaje).
        tokenizer: Tokenizer del modelo E5.

    Returns:
        Lista de chunks decodificados (sin el prefijo).
    """
    ids = tokenizer.encode(texto, add_special_tokens=False)
    maximo = CONFIG["tamano_chunk"] - CONFIG["reserva_prefijo_tokens"]
    solape = CONFIG["solape_chunk"]
    chunks: list[str] = []
    inicio = 0
    total = len(ids)
    while inicio < total:
        fin = min(inicio + maximo, total)
        chunks.append(tokenizer.decode(ids[inicio:fin], skip_special_tokens=True))
        if fin == total:
            break
        inicio = fin - solape
    return chunks


def _codificar_con_fallback(modelo: object, textos: list[str]) -> np.ndarray:
    """Codifica textos con E5 reintentando con batch menor ante OOM.

    Args:
        modelo: SentenceTransformer cargado en el dispositivo elegido.
        textos: Textos con prefijo ya incluido.

    Returns:
        Matriz de embeddings normalizados (n, dim).
    """
    try:
        return np.asarray(
            modelo.encode(
                textos,
                batch_size=CONFIG["batch_embedding"],
                normalize_embeddings=True,
                show_progress_bar=False,
                convert_to_numpy=True,
            )
        )
    except RuntimeError:
        print(
            "[aviso] OOM en E5: se re-codifica con batch "
            f"{CONFIG['batch_embedding_oom']} (documentado)"
        )
        return np.asarray(
            modelo.encode(
                textos,
                batch_size=CONFIG["batch_embedding_oom"],
                normalize_embeddings=True,
                show_progress_bar=False,
                convert_to_numpy=True,
            )
        )


def media_por_grupos(matriz: np.ndarray, longitudes: list[int]) -> np.ndarray:
    """Agrega por media (chunk-mean de ADR-3) y renormaliza cada grupo.

    Args:
        matriz: Embeddings planos (sum(longitudes), dim).
        longitudes: Numero de chunks de cada documento, en orden.

    Returns:
        Matriz (len(longitudes), dim) con un vector unitario por documento.
    """
    vectores = []
    inicio = 0
    for n_chunks in longitudes:
        bloque = matriz[inicio : inicio + n_chunks]
        inicio += n_chunks
        media = bloque.mean(axis=0)
        norma = float(np.linalg.norm(media))
        vectores.append(media / norma if norma > 0 else media)
    return np.vstack(vectores)


def scores_e5_caso(
    vectores_query: np.ndarray, matriz_pasajes: np.ndarray, grupos_indices: list[np.ndarray]
) -> np.ndarray:
    """Scores E5 por articulo: max coseno entre chunks de query y pasajes.

    Cada chunk de la query se compara con todos los pasajes; el score del
    pasaje es el maximo entre chunks y el del articulo el maximo entre sus
    pasajes (max-pooling en ambos niveles, CONFIG['agregacion_chunks_e5']).

    Args:
        vectores_query: Matriz (n_chunks, dim) de embeddings unitarios de
            los chunks de la query.
        matriz_pasajes: Matriz (n_pasajes, dim) de embeddings unitarios.
        grupos_indices: Arrays de posiciones de pasajes por articulo.

    Returns:
        Array (n_articulos,) de similitudes maximas por articulo.
    """
    similitudes = matriz_pasajes @ vectores_query.T
    maximos_pasajes = similitudes.max(axis=1)
    scores = np.zeros(len(grupos_indices), dtype=np.float64)
    for i, indices in enumerate(grupos_indices):
        scores[i] = maximos_pasajes[indices].max()
    return scores


# ===== SECCION 7: estrategia hibrida pre-registrada (mejora 6) =====
def normalizar_min_max(scores: np.ndarray) -> np.ndarray:
    """Normaliza min-max un vector de scores por caso.

    Si todos los scores son iguales (maximo == minimo) devuelve ceros: esa
    estrategia no discrimina en ese caso y no aporta al hibrido.

    Args:
        scores: Array de scores de una estrategia para un caso.

    Returns:
        Array normalizado a [0, 1].
    """
    minimo, maximo = float(scores.min()), float(scores.max())
    if maximo <= minimo:
        return np.zeros_like(scores)
    return (scores - minimo) / (maximo - minimo)


def scores_hibridos(scores_bm25: np.ndarray, scores_e5: np.ndarray) -> np.ndarray:
    """Combina BM25 y E5 con pesos pre-registrados 0.5/0.5 (min-max por caso).

    Args:
        scores_bm25: Scores BM25 del caso (n_articulos,).
        scores_e5: Scores E5 del caso (n_articulos,).

    Returns:
        Array (n_articulos,) de scores hibridos.
    """
    pesos = CONFIG["pesos_hibrido"]
    return (
        pesos["bm25"] * normalizar_min_max(scores_bm25)
        + pesos["e5"] * normalizar_min_max(scores_e5)
    )


# ===== SECCION 8: figura de deriva temporal =====
def graficar_deriva(por_caso: pd.DataFrame) -> None:
    """Genera figuras/deriva_retrieval_v2.png con F1@5 y MRR por anio.

    Con 3 casos/anio las series se promedian por anio (mas estables que
    el v1, que tenia 1 caso/anio).

    Args:
        por_caso: DataFrame largo con ano, estrategia y medidas.
    """
    etiquetas = {
        "cita_exacta": "cita-exacta (regex M2, circular)",
        "bm25": "BM25 (pasajes + chunks + bigramas LLR)",
        "e5": "E5-multilingual (pasajes, max-pooling)",
        "hibrido": "hibrido 0.5*BM25 + 0.5*E5",
    }
    colores = {
        "cita_exacta": "#7f7f7f",
        "bm25": "#1f77b4",
        "e5": "#d62728",
        "hibrido": "#2ca02c",
    }
    series = (
        por_caso.groupby(["ano", "estrategia"])[list(MEDIDAS)]
        .mean()
        .reset_index()
    )
    figura, ejes = plt.subplots(2, 1, figsize=(11, 8), sharex=True)
    for medida, eje, titulo in (
        ("f1_at_k", ejes[0], "F1@5 sentencia->articulos CP por anio (3 casos/anio)"),
        ("mrr", ejes[1], "MRR por anio"),
    ):
        for estrategia in CONFIG["estrategias"]:
            serie = series[series["estrategia"] == estrategia].sort_values("ano")
            eje.plot(
                serie["ano"],
                serie[medida],
                marker="o",
                markersize=4,
                linewidth=1.1,
                color=colores[estrategia],
                label=etiquetas[estrategia],
            )
        eje.set_ylabel(medida.upper())
        eje.set_title(titulo, fontsize=10)
        eje.grid(True, alpha=0.3)
        eje.legend(fontsize=8, loc="upper right")
    ejes[1].set_xlabel("Anio de la sentencia")
    ejes[1].set_xticks(range(CONFIG["ano_min"], CONFIG["ano_max"] + 1, 3))
    figura.tight_layout()
    Path(CONFIG["ruta_figura"]).parent.mkdir(parents=True, exist_ok=True)
    figura.savefig(CONFIG["ruta_figura"], dpi=150, bbox_inches="tight")
    plt.close(figura)


# ===== SECCION 9: guardado =====
def guardar_json(ruta: str, contenido: dict) -> None:
    """Guarda un dict como JSON UTF-8 con indentacion.

    Args:
        ruta: Ruta del archivo de salida.
        contenido: Dict serializable.
    """
    Path(ruta).parent.mkdir(parents=True, exist_ok=True)
    with Path(ruta).open("w", encoding="utf-8") as manejador:
        json.dump(contenido, manejador, ensure_ascii=False, indent=2)


def cargar_globales_v1() -> dict | None:
    """Lee los resultados globales del benchmark v1 para comparar (solo lectura).

    Returns:
        Dict {estrategia: {medidas}} del v1, o None si no existe el archivo.
    """
    ruta = Path(CONFIG["ruta_benchmark_v1"])
    if not ruta.exists():
        return None
    with ruta.open("r", encoding="utf-8") as manejador:
        return json.load(manejador).get("global")


# ===== SECCION 10: orquestacion principal =====
def main() -> None:
    """Orquesta el benchmark M7 v2 con las seis mejoras pre-registradas."""
    inicio_total = time.time()
    resolver_rutas()
    configurar_semillas(CONFIG["semilla"])
    dispositivo = elegir_dispositivo()
    print(
        f"GPU disponible: {torch.cuda.is_available()} | "
        f"device E5: {dispositivo}"
    )

    # --- pasajes de la Constitucion (mejora 1) ---
    pasajes, canones, grupos_indices = preparar_pasajes_constitucion()
    canon_valido = set(canones)
    pasajes_por_articulo = [len(g) for g in grupos_indices]
    print(
        f"Constitucion: {len(canones)} articulos -> {len(pasajes)} pasajes "
        f"(media {np.mean(pasajes_por_articulo):.1f}, max "
        f"{max(pasajes_por_articulo)})"
    )

    # --- marco del corpus y weak labels (solo columnas ligeras) ---
    marco = pd.read_parquet(
        CONFIG["ruta_corpus"], columns=["id", "tipo", "ano"]
    )
    marco["id"] = marco["id"].astype(str)
    marco["tipo"] = marco["tipo"].astype(str)
    marco["ano"] = marco["ano"].astype(int)
    entidades = pd.read_parquet(
        CONFIG["ruta_entidades"], columns=["id", "arts_cp"]
    )
    entidades["id"] = entidades["id"].astype(str)
    etiquetas_por_id = dict(zip(entidades["id"], entidades["arts_cp"], strict=True))

    def arts_validos(sid: str) -> list[str]:
        crudo = etiquetas_por_id.get(sid)
        lista = json.loads(crudo) if crudo else []
        return [a for a in lista if a in canon_valido]

    marco["labeled"] = marco["id"].apply(lambda sid: len(arts_validos(sid)) > 0)

    # --- muestra temporal 3/anio estratificada (mejora 5) ---
    muestra = cargar_muestra_temporal(marco)
    ids_muestra = muestra["id"].tolist()
    textos_muestra = leer_filas_por_id(
        CONFIG["ruta_corpus"], ["id", "texto", "texto_limpio"], ids_muestra
    )
    textos_muestra["id"] = textos_muestra["id"].astype(str)
    crudo_por_id = dict(
        zip(textos_muestra["id"], textos_muestra["texto"], strict=True)
    )
    limpio_por_id = dict(
        zip(textos_muestra["id"], textos_muestra["texto_limpio"], strict=True)
    )
    casos = []
    for _, fila in muestra.iterrows():
        sid = str(fila["id"])
        casos.append(
            {
                "id": sid,
                "tipo": str(fila["tipo"]),
                "ano": int(fila["ano"]),
                "texto": str(crudo_por_id.get(sid, "")),
                "texto_limpio": str(limpio_por_id.get(sid, "")),
                "arts": arts_validos(sid),
            }
        )
    print(
        f"Muestra temporal: {len(casos)} sentencias "
        f"({CONFIG['muestra_por_ano']}/anio, semilla {CONFIG['semilla']}), "
        f"tipos {muestra['tipo'].value_counts().to_dict()}"
    )

    # --- chunks de query sobre el texto completo (mejora 2) ---
    for caso in casos:
        caso["ventana"] = caso["texto_limpio"][: CONFIG["ventana_query_chars"]]
        caso["chunks_bm25"] = chunks_query(caso["ventana"])
        caso["rankings"] = {}
    chars_ventana = [len(c["ventana"]) for c in casos]
    print(
        f"Query: media {np.mean(chars_ventana):.0f} chars de texto completo, "
        f"media {np.mean([len(c['chunks_bm25']) for c in casos]):.1f} chunks BM25"
    )

    # --- estrategia (a): cita-exacta con regex M2 (referencia circular) ---
    modulo_m2 = importar_extraccion_m2()
    for caso in casos:
        caso["rankings"]["cita_exacta"] = modulo_m2.extraer_arts_cp(
            caso["texto"], CONFIG["ventana_cp"]
        )

    # --- estrategia (b): BM25 por pasajes con query en chunks (mejoras 1-3) ---
    inicio_bm25 = time.time()
    indice_bm25 = construir_indice_bm25(pasajes)
    for caso in casos:
        scores = scores_bm25_caso(
            indice_bm25, grupos_indices, canones, caso["chunks_bm25"]
        )
        caso["scores_bm25"] = scores
        caso["rankings"]["bm25"] = ranking_desde_scores(scores, canones)
    print(f"BM25 por pasajes: {time.time() - inicio_bm25:.1f} s")

    # --- estrategia (c): E5-multilingual por pasajes en GPU (mejora 4) ---
    from sentence_transformers import SentenceTransformer
    from sentence_transformers import models as st_models

    backbone = st_models.Transformer(
        CONFIG["modelo_e5"], max_seq_length=CONFIG["tamano_chunk"]
    )
    pooling = st_models.Pooling(
        backbone.get_embedding_dimension(), pooling_mode="mean"
    )
    modelo_e5 = SentenceTransformer(modules=[backbone, pooling], device=dispositivo)
    tokenizer = modelo_e5.tokenizer

    # Pasajes: chunk-mean por pasaje si excede el limite de tokens.
    grupos_pasajes = [
        chunkear_texto(t, tokenizer) or [""] for t in pasajes["texto"].tolist()
    ]
    longitudes_pasajes = [len(g) for g in grupos_pasajes]
    textos_pasajes = [
        CONFIG["prefijo_pasaje"] + chunk
        for grupo in grupos_pasajes
        for chunk in grupo
    ]
    inicio_e5 = time.time()
    emb_pasajes = _codificar_con_fallback(modelo_e5, textos_pasajes)
    matriz_pasajes = media_por_grupos(emb_pasajes, longitudes_pasajes)
    print(
        f"E5: {len(textos_pasajes)} chunks de {len(pasajes)} pasajes "
        f"codificados en {time.time() - inicio_e5:.1f} s ({dispositivo})"
    )

    # Queries: chunks del texto completo; el score usa max-pooling por
    # chunk (scores_e5_caso), no chunk-mean.
    grupos_query = [chunkear_texto(c["ventana"], tokenizer) or [""] for c in casos]
    longitudes_query = [len(g) for g in grupos_query]
    textos_query = [
        CONFIG["prefijo_query"] + chunk
        for grupo in grupos_query
        for chunk in grupo
    ]
    inicio_query = time.time()
    emb_query = _codificar_con_fallback(modelo_e5, textos_query)
    print(
        f"E5: {len(textos_query)} chunks de query codificados en "
        f"{time.time() - inicio_query:.1f} s "
        f"(media {np.mean(longitudes_query):.1f} chunks/sentencia)"
    )
    inicio = 0
    for caso, n_chunks in zip(casos, longitudes_query, strict=True):
        vectores_query = emb_query[inicio : inicio + n_chunks]
        inicio += n_chunks
        scores = scores_e5_caso(vectores_query, matriz_pasajes, grupos_indices)
        caso["scores_e5"] = scores
        caso["rankings"]["e5"] = ranking_desde_scores(scores, canones)

    # --- estrategia (d): hibrido pre-registrado 0.5/0.5 (mejora 6) ---
    for caso in casos:
        scores = scores_hibridos(caso["scores_bm25"], caso["scores_e5"])
        caso["rankings"]["hibrido"] = ranking_desde_scores(scores, canones)

    # --- evaluacion global, por anio y por periodo ---
    por_caso = metricas_por_caso(casos)
    globales = {
        estrategia: promediar_metricas(
            por_caso[por_caso["estrategia"] == estrategia].to_dict("records")
        )
        for estrategia in CONFIG["estrategias"]
    }
    por_periodo = agregar_por_periodo(por_caso)

    # recall de extraccion de la cita-exacta (circular, se reporta aparte)
    recalls = []
    for caso in casos:
        predichos = set(caso["rankings"]["cita_exacta"])
        etiquetas = set(caso["arts"])
        recalls.append(len(predichos & etiquetas) / len(etiquetas) if etiquetas else 0.0)
    recall_extraccion = float(np.mean(recalls))

    # --- guardado de resultados ---
    ganadora = max(globales, key=lambda e: globales[e]["f1_at_k"])
    benchmark = {
        "fecha": datetime.now(timezone.utc).isoformat(),
        "descripcion": (
            "Benchmark M7 v2 (Fase K-2, recalibracion) vinculo "
            "sentencia->articulos CP sobre weak labels M2 (ADR-5): "
            f"{CONFIG['muestra_por_ano']} sentencias/anio 1992-2021, "
            f"semilla {CONFIG['semilla']}, cupos proporcionales al tipo"
        ),
        "config": {
            "k": CONFIG["k"],
            "modelo_e5": CONFIG["modelo_e5"],
            "chunk_e5": CONFIG["tamano_chunk"],
            "solape_e5": CONFIG["solape_chunk"],
            "batch_embedding": CONFIG["batch_embedding"],
            "dispositivo_e5": dispositivo,
            "ventana_query_chars": CONFIG["ventana_query_chars"],
            "chunk_bm25_chars": CONFIG["chunk_bm25_chars"],
            "solape_bm25_chars": CONFIG["solape_bm25_chars"],
            "pasaje_max_palabras": CONFIG["pasaje_max_palabras"],
            "agregacion_pasajes": CONFIG["agregacion_pasajes"],
            "agregacion_chunks_bm25": CONFIG["agregacion_chunks_bm25"],
            "agregacion_chunks_e5": CONFIG["agregacion_chunks_e5"],
            "muestra_por_ano": CONFIG["muestra_por_ano"],
            "pesos_hibrido": CONFIG["pesos_hibrido"],
            "stopwords_juridicas": sorted(CONFIG["stopwords_juridicas"]),
            "bigramas_llr": sorted(" ".join(par) for par in CONFIG["bigramas_llr"]),
            "nota_cita_exacta": (
                "La estrategia cita-exacta es circular por construccion "
                "(mismo regex M2 que genero los weak labels): su recall de "
                "extraccion se reporta por separado."
            ),
        },
        "pasajes_stats": {
            "n_articulos": len(canones),
            "n_pasajes": len(pasajes),
            "media_por_articulo": float(np.mean(pasajes_por_articulo)),
            "max_por_articulo": int(max(pasajes_por_articulo)),
        },
        "query_stats": {
            "cobertura": "texto completo (ventana infinita; refutada la ventana corta)",
            "media_chars_query": float(np.mean(chars_ventana)),
            "media_chunks_bm25": float(np.mean([len(c["chunks_bm25"]) for c in casos])),
            "media_chunks_e5": float(np.mean(longitudes_query)),
        },
        "muestra": [
            {"id": c["id"], "tipo": c["tipo"], "ano": c["ano"], "arts_cp": c["arts"]}
            for c in casos
        ],
        "recall_extraccion_cita_exacta": recall_extraccion,
        "global": globales,
        "por_periodo": por_periodo,
        "estrategia_ganadora_f1_at_k": ganadora,
        "comparacion_v1_global": cargar_globales_v1(),
        "tiempos_segundos": {
            "bm25": round(time.time() - inicio_bm25, 1),
            "e5_pasajes": round(time.time() - inicio_e5 - (time.time() - inicio_query), 1),
            "e5_query": round(time.time() - inicio_query, 1),
            "total": round(time.time() - inicio_total, 1),
        },
    }
    guardar_json(CONFIG["ruta_benchmark"], benchmark)

    por_caso[["id", "ano", "estrategia", "n_relevantes", *MEDIDAS]].to_csv(
        CONFIG["ruta_por_ano"], index=False, encoding="utf-8"
    )
    graficar_deriva(por_caso)

    # --- resumen final ---
    print("\n=== Resumen M7 v2 (global, k=5) ===")
    for estrategia in CONFIG["estrategias"]:
        m = globales[estrategia]
        print(
            f"{estrategia:11s} P@5={m['p_at_k']:.3f} R@5={m['r_at_k']:.3f} "
            f"F1@5={m['f1_at_k']:.3f} MRR={m['mrr']:.3f}"
        )
    print(f"recall extraccion (cita-exacta, circular): {recall_extraccion:.3f}")
    for nombre, _, _ in CONFIG["periodos"]:
        fila = por_periodo[nombre]
        print(
            f"periodo {nombre}: F1@5 bm25={fila['bm25']['f1_at_k']:.3f} | "
            f"e5={fila['e5']['f1_at_k']:.3f} | "
            f"hibrido={fila['hibrido']['f1_at_k']:.3f}"
        )
    print(f"ganadora por F1@5: {ganadora}")
    print(
        f"tiempo total: {time.time() - inicio_total:.1f} s | "
        f"salidas: {CONFIG['ruta_benchmark']}, {CONFIG['ruta_por_ano']}, "
        f"{CONFIG['ruta_figura']}"
    )


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:  # noqa: BLE001
        traceback.print_exc()
        print(f"Error fatal: {exc}")
        sys.exit(1)
