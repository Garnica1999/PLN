"""componentes_producto.py
Fecha: 2026-09-09
Descripcion: Componentes reutilizables del producto final Juris-PLN (Fase N).
    Cada clase envuelve un modulo ya entrenado/validado del proyecto sin
    duplicar su logica: ValidadorEntrada (M0, port de
    scripts/lib/validacion_entrada.py), ExtractorEntidades (M2, importlib de
    scripts/03_extraccion_entidades.py), ClasificadorArea (M4, TF-IDF de lemas
    enmascarados + LogReg de modelos/m4_baseline), VinculoCP (M7 v2, BM25 por
    pasajes con max-pooling de chunks, port de scripts/12_evaluar_vinculo_cp_v2.py
    con cache del indice en data/cache_bm25_cp/) y ContextoJurisprudencial
    (M5, citas resueltas al corpus + PageRank + area desde
    data/red_citas_resumen.parquet).
Estado del arte aplicado: heuristica lexica M0 (accuracy 1.0 en 52 casos),
    NER regex M2 (precision muestral >= 0.90), TF-IDF de lemas enmascarados
    con LogReg multinomial (macro-F1 0.287), BM25 por pasajes con bigramas
    LLR y stopwords juridicas (F1@5 0.218) y PageRank de la red de citas.
"""

import importlib.util
import itertools
import re
import unicodedata
from collections import Counter
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from rank_bm25 import BM25Okapi

CONFIG = {
    "ventana_cp": 60,
    "zona_encabezado_chars": 3000,
    "k_bm25_default": 5,
    "chunk_bm25_chars": 800,
    "solape_bm25_chars": 200,
    "pasaje_max_palabras": 120,
    "modelo_spacy": "es_core_news_md",
    "spacy_max_length": 5_000_000,
    "ruta_validacion": "scripts/lib/validacion_entrada.py",
    "ruta_script_m2": "scripts/03_extraccion_entidades.py",
    "ruta_constitucion": "data/constitucion_articulos.parquet",
    "ruta_red_citas": "data/red_citas_resumen.parquet",
    "ruta_corpus": "data/corpus_sentencias.parquet",
    "ruta_tfidf": "modelos/m4_baseline/tfidf_enmascarado.joblib",
    "ruta_logreg": "modelos/m4_baseline/logreg_enmascarado.joblib",
    "dir_cache_bm25": "data/cache_bm25_cp",
    "archivo_cache_bm25": "indice_bm25_cp_v2.joblib",
    "version_cache": 2,
}

ROOT = Path(__file__).resolve().parent.parent.parent

# Stopwords juridicas (port de 12_evaluar_vinculo_cp_v2.py): terminos
# procesales presentes en casi todas las sentencias que no discriminan entre
# articulos de la CP. Los bigramas compuestos (con "_") nunca se filtran.
STOPWORDS_JURIDICAS = frozenset(
    {
        "articulo", "articulos", "ley", "leyes", "numeral", "numerales",
        "inciso", "incisos", "parrafo", "parrafos", "literal", "literales",
        "caso", "casos", "sentencia", "sentencias", "expediente", "bogota",
        "honorable", "magistrado", "magistrados", "ponente", "secretaria",
        "general", "demanda", "demandas", "demandado", "demandados",
        "demandada", "demandadas", "demandante", "demandantes", "dos",
        "mil", "senor", "senora", "senores",
    }
)

# Bigramas LLR ganadores del EDA de PRIMERA ENTREGA (port de 12): top-20 de
# resultados/eda_extendido/colocaciones.csv con exclusiones documentadas
# (fechas, conectivos procesales y nombres propios).
BIGRAMAS_LLR = frozenset(
    {
        ("derechos", "fundamentales"),
        ("corte", "constitucional"),
        ("seguridad", "social"),
        ("constitucion", "politica"),
        ("debido", "proceso"),
        ("derecho", "fundamental"),
        ("minimo", "vital"),
        ("primera", "instancia"),
        ("perjuicio", "irremediable"),
        ("cosa", "juzgada"),
        ("derechos", "humanos"),
        ("corte", "suprema"),
        ("tribunal", "superior"),
        ("segunda", "instancia"),
    }
)

# ===== Enmascarado de lemas (replica de 06_baseline_clasico.py, Fase L2) =====
# Lemas nucleo de citas normativas tras la lematizacion (formas con y sin
# tilde; "politica" excluido por no ser nucleo de cita).
LEMAS_CITA = {
    "articulo", "articulos", "ley", "leyes", "decreto", "decretos",
    "acto", "legislativo", "sentencia", "sentencias", "auto",
    "numeral", "numerales", "inciso", "incisos", "literal", "literales",
    "paragrafo", "constitucion",
}
TOKEN_CITA = "CITA"
# Romanos REALES (regex estricta; evita falsos como civil/mi/mil).
RE_ROMANO = re.compile(
    r"^(?=.{1,7}$)m{0,4}(cm|cd|d?c{0,3})(xc|xl|l?x{0,3})(ix|iv|v?i{0,3})$",
    re.IGNORECASE,
)
RE_ARABIGO = re.compile(r"^\d{1,4}$")
# Prefijos de sentencia citada ya lematizados (t, c, su + numero).
RE_SENT_CITADA = re.compile(r"^(?:t|c|su)$", re.IGNORECASE)


# ===== SECCION 1: utilidades base =====
def _cargar_modulo(ruta: Path, nombre: str) -> object:
    """Carga un modulo Python por ruta con importlib.

    Los scripts del proyecto empiezan por digito (03_...) o viven en lib/
    sin paquete, por lo que no admiten import estandar; se cargan con spec
    para reutilizar sus funciones sin duplicar logica.

    Args:
        ruta: Ruta absoluta al archivo .py a cargar.
        nombre: Nombre con el que se registra el modulo.

    Returns:
        Modulo Python ejecutado (solo definiciones si tiene main guard).

    Raises:
        RuntimeError: Si la ruta no existe o el spec no se puede crear.
    """
    if not ruta.is_file():
        raise RuntimeError(f"No se encontro el modulo a cargar: {ruta}")
    spec = importlib.util.spec_from_file_location(nombre, ruta)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"No se pudo crear spec de importlib para: {ruta}")
    modulo = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(modulo)
    return modulo


def normalizar_sin_tildes(texto: str) -> str:
    """Convierte un texto a minusculas y sin diacriticos.

    Args:
        texto: Texto original.

    Returns:
        Texto normalizado (minusculas, sin tildes).
    """
    sin_tildes = "".join(
        c for c in unicodedata.normalize("NFD", texto) if not unicodedata.combining(c)
    )
    return sin_tildes.lower()


def tokenizar(texto: str) -> list[str]:
    """Tokeniza para BM25: unigramas sin stopwords juridicas + bigramas LLR.

    Port de 12_evaluar_vinculo_cp_v2.py: los bigramas se detectan sobre la
    secuencia completa de unigramas y se anaden como tokens "a_b"; despues
    se filtran los unigramas procesales.

    Args:
        texto: Texto a tokenizar.

    Returns:
        Lista de tokens (unigramas utiles + bigramas compuestos).
    """
    tokens = re.findall(r"[a-z0-9]+", normalizar_sin_tildes(texto))
    bigramas = [
        f"{a}_{b}"
        for a, b in itertools.pairwise(tokens)
        if (a, b) in BIGRAMAS_LLR
    ]
    unigramas = [t for t in tokens if t not in STOPWORDS_JURIDICAS]
    return unigramas + bigramas


def dividir_pasajes(texto: str, max_palabras: int) -> list[str]:
    """Segmenta un articulo en pasajes de oraciones completas.

    Port de 12_evaluar_vinculo_cp_v2.py: split tras punto agrupando
    oraciones hasta max_palabras; una oracion mas larga que el limite queda
    como pasaje propio.

    Args:
        texto: Texto del articulo.
        max_palabras: Limite de palabras por pasaje.

    Returns:
        Lista de pasajes (>= 1 para todo texto no vacio).
    """
    oraciones = [o.strip() for o in re.split(r"(?<=\.)\s+", texto) if o.strip()]
    pasajes: list[str] = []
    actual: list[str] = []
    palabras = 0
    for oracion in oraciones:
        largo = len(oracion.split())
        if palabras + largo > max_palabras and actual:
            pasajes.append(" ".join(actual))
            actual, palabras = [], 0
        actual.append(oracion)
        palabras += largo
    if actual:
        pasajes.append(" ".join(actual))
    return pasajes if pasajes else ([texto.strip()] if texto.strip() else [])


def es_numero_cita(token: str) -> bool:
    """Determina si un token de lemas puede ser el numero de una cita.

    Args:
        token: Token (posible arabigo o romano).

    Returns:
        True si es arabigo de 1-4 digitos o romano real.
    """
    return bool(RE_ARABIGO.match(token) or RE_ROMANO.match(token))


def normalizar_lemas(texto: str) -> str:
    """Normaliza lemas multi-palabra a un solo token con guion bajo.

    Replica de 06_baseline_clasico.py: spaCy emite lemas con espacio
    ("hacer el") que deben unirse como "hacer_el" antes de vectorizar.

    Args:
        texto: Secuencia de lemas separados por espacio.

    Returns:
        Secuencia con lemas multi-palabra unidos por "_".
    """
    return " ".join(tok.replace(" ", "_") for tok in texto.split())


def enmascarar_citas_lemas(texto: str) -> str:
    """Enmascara secuencias de lemas tipicas de citas normativas.

    Replica de 06_baseline_clasico.py (version auditada L2): nucleo de cita
    (con/sin tilde, singular/plural) + numero arabigo o romano estricto,
    series con conectores ("articulo 11 y 13") y prefijos de sentencia
    citada (t/c/su + numero [+ de + ano]) se reemplazan por el token CITA.

    Args:
        texto: Secuencia de lemas normalizados (normalizar_lemas previo).

    Returns:
        Secuencia con las citas reemplazadas por CITA.
    """
    tokens = texto.split()
    salida: list[str] = []
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        base = tok.split("_")[0]
        if base in LEMAS_CITA:
            j = i + 1
            consumio_numero = False
            while j < len(tokens):
                sig = tokens[j]
                if es_numero_cita(sig):
                    consumio_numero = True
                    j += 1
                elif consumio_numero and sig in {
                    "de", "del", "y", "la", "el", "las", "los",
                }:
                    j += 1
                    if j < len(tokens) and es_numero_cita(tokens[j]):
                        continue
                    j -= 1
                    break
                else:
                    break
            if consumio_numero:
                salida.append(TOKEN_CITA)
                i = j
            else:
                salida.append(tok)
                i += 1
        elif (
            RE_SENT_CITADA.match(base)
            and i + 1 < len(tokens)
            and es_numero_cita(tokens[i + 1])
        ):
            j = i + 2
            if (
                j < len(tokens)
                and tokens[j] == "de"
                and j + 1 < len(tokens)
                and es_numero_cita(tokens[j + 1])
            ):
                j += 2
            salida.append(TOKEN_CITA)
            i = j
        else:
            salida.append(tok)
            i += 1
    return " ".join(salida)


# ===== SECCION 2: M0 validacion de entrada =====
class ValidadorEntrada:
    """M0: decide si un texto es providencia de la Corte Constitucional.

    Envuelve scripts/lib/validacion_entrada.py (heuristica del anexo 25:
    encabezado de sentencia, marcador "corte constitucional" y marcador
    "magistrado ponente"; umbral 2/3 reglas, accuracy 1.0 en 52 casos).
    """

    def __init__(self) -> None:
        """Carga el modulo M0 por importlib (port sin duplicacion)."""
        self._m0 = _cargar_modulo(
            ROOT / CONFIG["ruta_validacion"], "validacion_entrada_producto"
        )

    def validar(self, texto: str) -> dict:
        """Evalua las tres reglas M0 sobre un texto.

        Args:
            texto: Texto completo del documento a validar (crudo).

        Returns:
            Dict con es_sentencia (bool, umbral 2/3), score_validacion
            (reglas cumplidas / total, en [0, 1]) y reglas (detalle del
            cumplimiento por regla; None si el texto es vacio).
        """
        if not isinstance(texto, str) or not texto.strip():
            return {
                "es_sentencia": False,
                "score_validacion": 0.0,
                "reglas": None,
            }
        res = self._m0.evaluar_reglas(texto)
        return {
            "es_sentencia": bool(res["es_sentencia"]),
            "score_validacion": res["reglas_cumplidas"] / res["total_reglas"],
            "reglas": {
                "encabezado": res["encabezado"],
                "marcador_corte": res["marcador_corte"],
                "marcador_ponente": res["marcador_ponente"],
            },
        }


# ===== SECCION 3: M2 extraccion de entidades =====
class ExtractorEntidades:
    """M2: extraccion de entidades juridicas por regex (NER del proyecto).

    Envuelve scripts/03_extraccion_entidades.py via importlib: articulos de
    la CP citados (ventana de constitucionalidad), sentencias citadas en
    canon TIPO-NUM-AAAA y magistrado ponente.
    """

    def __init__(self, ventana_cp: int | None = None) -> None:
        """Carga el modulo M2 y fija la ventana de constitucionalidad.

        Args:
            ventana_cp: Radio en caracteres para vincular articulo y
                constitucion (default CONFIG["ventana_cp"] = 60).
        """
        self._m2 = _cargar_modulo(
            ROOT / CONFIG["ruta_script_m2"], "extraccion_m2_producto"
        )
        self._ventana = ventana_cp or CONFIG["ventana_cp"]

    def extraer(self, texto: str) -> dict:
        """Extrae articulos CP, sentencias citadas y ponente de un texto.

        Args:
            texto: Texto crudo de la sentencia.

        Returns:
            Dict con arts_cp (lista de canones "13"/"22A" unicos en orden),
            sents_citadas (lista de canones "T-293-1997" unicos en orden) y
            ponente (nombre o None).
        """
        contadores: Counter = Counter()
        menciones: Counter = Counter()
        return {
            "arts_cp": self._m2.extraer_arts_cp(texto, self._ventana),
            "sents_citadas": self._m2.extraer_sents(texto, contadores, menciones),
            "ponente": self._m2.extraer_ponente(texto),
        }

    def detectar_canon_encabezado(self, texto: str) -> str | None:
        """Detecta el canon TIPO-NUM-AAAA propio del encabezado.

        Recorre las citas del M2 sobre la zona inicial del texto y devuelve
        la primera valida (T/C/SU con ano en rango): en una providencia el
        canon propio aparece antes que cualquier cita del cuerpo.

        Args:
            texto: Texto crudo de la sentencia.

        Returns:
            Canon "T-293-1997" o None si el encabezado no casa.
        """
        zona = texto[: CONFIG["zona_encabezado_chars"]]
        for coinc in self._m2.RE_SENT.finditer(zona):
            base = coinc.group(1).upper()
            tipo = "SU" if base == "S" and coinc.group(2) else base
            if tipo not in {"T", "C", "SU"}:
                continue
            ano = self._m2.normalizar_ano_cita(coinc.group(4))
            if ano is None:
                continue
            return f"{tipo}-{int(coinc.group(3))}-{ano}"
        return None


# ===== SECCION 4: M4 clasificador de area tematica =====
class ClasificadorArea:
    """M4: clasifica el area tematica constitucional de la sentencia.

    Pipeline heredado de 06_baseline_clasico.py (macro-F1 0.287): lemas
    spaCy del texto crudo (is_alpha, minusculas) -> normalizacion de lemas
    multi-palabra con "_" -> enmascarado de citas -> TF-IDF -> LogReg
    multinomial; devuelve el top-3 de areas con probabilidad.
    """

    def __init__(self) -> None:
        """Carga el vectorizador TF-IDF y el LogReg enmascarados (joblib)."""
        self._vectorizador = joblib.load(ROOT / CONFIG["ruta_tfidf"])
        self._modelo = joblib.load(ROOT / CONFIG["ruta_logreg"])
        self._nlp = None

    def _cargar_spacy(self) -> None:
        """Carga el pipeline spaCy (lazy, sin parser ni NER).

        Solo se necesita el lematizador; excluir parser/NER reduce el tiempo
        de carga y de procesamiento en CPU moderada.
        """
        if self._nlp is None:
            import spacy

            self._nlp = spacy.load(
                CONFIG["modelo_spacy"], exclude=["parser", "ner"]
            )
            self._nlp.max_length = CONFIG["spacy_max_length"]

    def clasificar(self, texto: str) -> dict:
        """Clasifica el area tematica y devuelve el top-3 con probabilidad.

        Args:
            texto: Texto crudo de la sentencia.

        Returns:
            Dict con top3 (lista de {area, prob} ordenada por probabilidad
            descendente) y via (identificador del metodo del producto).

        Raises:
            ValueError: Si el texto es vacio o no es cadena.
        """
        if not isinstance(texto, str) or not texto.strip():
            raise ValueError("El clasificador M4 requiere un texto no vacio.")
        self._cargar_spacy()
        doc = self._nlp(texto)
        lemas = " ".join(
            tok.lemma_.lower().strip() for tok in doc if tok.is_alpha
        )
        mascarada = enmascarar_citas_lemas(normalizar_lemas(lemas))
        matriz = self._vectorizador.transform([mascarada])
        probs = self._modelo.predict_proba(matriz)[0]
        pares = sorted(
            zip(self._modelo.classes_, probs, strict=True),
            key=lambda par: -par[1],
        )
        top3 = [
            {"area": str(area), "prob": round(float(prob), 4)}
            for area, prob in pares[:3]
        ]
        return {"top3": top3, "via": "clasificador_m4_logreg_enmascarado"}


# ===== SECCION 5: M7 v2 vinculo con la Constitucion (BM25) =====
class VinculoCP:
    """M7 v2: recupera articulos de la CP vinculados a la sentencia.

    Port de la indexacion de 12_evaluar_vinculo_cp_v2.py: indice BM25 sobre
    PASAJES de los 497 articulos (oraciones agrupadas hasta 120 palabras),
    query en chunks de 800 chars con solape 200 y score del articulo =
    maximo sobre (chunks x pasajes). El indice se construye una sola vez y
    se cachea en data/cache_bm25_cp/ para no reindexar en cada llamada.
    """

    def __init__(self, usar_cache: bool = True) -> None:
        """Carga el indice BM25 desde cache o lo construye y persiste.

        Args:
            usar_cache: Si True (default) reutiliza el joblib del cache
                cuando existe y es valido; si False reconstruye siempre.
        """
        self._usar_cache = usar_cache
        datos = self._cargar_o_construir()
        self._canones: list[str] = datos["canones"]
        self._grupos: list[np.ndarray] = datos["grupos_indices"]
        self._indice: BM25Okapi = datos["indice"]
        self._articulos: dict = datos["articulos"]

    def _ruta_cache(self) -> Path:
        """Devuelve la ruta absoluta del archivo de cache del indice."""
        return ROOT / CONFIG["dir_cache_bm25"] / CONFIG["archivo_cache_bm25"]

    def _cargar_o_construir(self) -> dict:
        """Carga el cache del indice o lo construye desde la CP.

        El cache es valido si la version coincide y el numero de articulos
        es consistente; si esta corrupto o desactualizado se reconstruye.

        Returns:
            Dict con version, canones, grupos_indices, indice (BM25Okapi)
            y articulos (dict numero -> {texto, bloque}).
        """
        ruta = self._ruta_cache()
        if self._usar_cache and ruta.is_file():
            try:
                datos = joblib.load(ruta)
            except Exception:  # noqa: BLE001 - cache corrupto: reconstruir
                datos = None
            if (
                datos is not None
                and datos.get("version") == CONFIG["version_cache"]
                and len(datos["canones"]) == len(datos["articulos"])
            ):
                return datos
        datos = self._construir_indice()
        ruta.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(datos, ruta)
        return datos

    def _construir_indice(self) -> dict:
        """Indexa los pasajes de la Constitucion con la tokenizacion M7 v2.

        Returns:
            Dict con version, canones (497), grupos_indices (posiciones de
            pasajes por articulo), indice BM25Okapi y articulos (dict con
            texto completo y bloque tematico por articulo).
        """
        tabla = pd.read_parquet(ROOT / CONFIG["ruta_constitucion"])
        canones = tabla["numero"].astype(str).tolist()
        textos = tabla["texto"].fillna("").astype(str).tolist()
        filas: list[dict] = []
        grupos: list[np.ndarray] = []
        posicion = 0
        for canon, texto in zip(canones, textos, strict=True):
            indices: list[int] = []
            for trozo in dividir_pasajes(texto, CONFIG["pasaje_max_palabras"]):
                filas.append({"canon": canon, "texto": trozo})
                indices.append(posicion)
                posicion += 1
            grupos.append(np.asarray(indices, dtype=int))
        tokens = [tokenizar(fila["texto"]) for fila in filas]
        indice = BM25Okapi(tokens)
        articulos = {
            canon: {"texto": texto, "bloque": bloque}
            for canon, texto, bloque in zip(
                canones,
                textos,
                tabla["bloque_tematico"].tolist(),
                strict=True,
            )
        }
        return {
            "version": CONFIG["version_cache"],
            "canones": canones,
            "grupos_indices": grupos,
            "indice": indice,
            "articulos": articulos,
        }

    def _chunks_query(self, texto: str) -> list[str]:
        """Divide la query en chunks de caracteres con solape (cobertura total).

        Port de 12_evaluar_vinculo_cp_v2.py: la evidencia de calibracion
        refuto la ventana inicial corta (las citas aparecen a lo largo de
        todo el texto), por lo que la query es el texto completo.

        Args:
            texto: Texto de la sentencia (limpio si viene del corpus).

        Returns:
            Lista de chunks (>= 1 si el texto no esta vacio).
        """
        chunks: list[str] = []
        inicio = 0
        while inicio < len(texto):
            fin = min(inicio + CONFIG["chunk_bm25_chars"], len(texto))
            chunks.append(texto[inicio:fin])
            if fin >= len(texto):
                break
            inicio = fin - CONFIG["solape_bm25_chars"]
        return chunks

    def recuperar(self, texto: str, k: int | None = None) -> list[dict]:
        """Recupera los k articulos de la CP mas vinculados al texto.

        Score del pasaje = maximo entre chunks de la query; score del
        articulo = maximo entre sus pasajes (max-pooling doble, ADR-9).

        Args:
            texto: Texto de la sentencia (texto_limpio del corpus cuando
                este disponible; el tokenizador es robusto al crudo).
            k: Profundidad del ranking (default CONFIG["k_bm25_default"]).

        Returns:
            Lista de {numero, score} ordenada por score descendente.
        """
        profundidad = k or CONFIG["k_bm25_default"]
        if not isinstance(texto, str) or not texto.strip():
            return []
        if self._indice.corpus_size == 0:
            return []
        max_pasajes = np.zeros(self._indice.corpus_size, dtype=np.float64)
        for chunk in self._chunks_query(texto):
            tokens = tokenizar(chunk)
            if tokens:
                np.maximum(
                    max_pasajes, self._indice.get_scores(tokens), out=max_pasajes
                )
        scores = np.zeros(len(self._canones), dtype=np.float64)
        for i, indices in enumerate(self._grupos):
            scores[i] = float(max_pasajes[indices].max()) if len(indices) else 0.0
        orden = np.argsort(-scores, kind="stable")[:profundidad]
        return [
            {"numero": self._canones[i], "score": round(float(scores[i]), 4)}
            for i in orden
        ]

    def detalle_articulo(self, numero: str) -> dict | None:
        """Devuelve texto recortado y bloque tematico de un articulo CP.

        Args:
            numero: Canon del articulo ("13", "22A").

        Returns:
            Dict con texto_150chars y bloque, o None si el articulo no
            existe en la Constitucion parseada.
        """
        info = self._articulos.get(numero)
        if info is None:
            return None
        return {
            "texto_150chars": info["texto"][:150],
            "bloque": info["bloque"],
        }


# ===== SECCION 6: M5 contexto jurisprudencial =====
class ContextoJurisprudencial:
    """M5: resuelve citas a sentencias y agrega su contexto de la red.

    Carga data/red_citas_resumen.parquet (PageRank, ano y area por
    sentencia del corpus) y el marco ligero del corpus (canon -> id) para
    resolver cada cita canon TIPO-NUM-AAAA del M2.
    """

    def __init__(self) -> None:
        """Carga la red de citas y el mapa canon -> id del corpus."""
        red = pd.read_parquet(ROOT / CONFIG["ruta_red_citas"])
        self._por_id = {
            str(fila.id): {
                "ano": int(fila.ano),
                "pagerank": float(fila.pagerank),
                "area": str(fila.area),
            }
            for fila in red.itertuples(index=False)
        }
        corpus = pd.read_parquet(
            ROOT / CONFIG["ruta_corpus"], columns=["id", "tipo", "ano", "numero"]
        )
        self._canon_a_id = {
            f"{tipo}-{int(numero)}-{int(ano)}": str(id_doc)
            for tipo, numero, ano, id_doc in zip(
                corpus["tipo"],
                corpus["numero"],
                corpus["ano"],
                corpus["id"],
                strict=True,
            )
        }

    def id_de_canon(self, canon: str) -> str | None:
        """Resuelve un canon TIPO-NUM-AAAA al id del corpus.

        Args:
            canon: Canon de sentencia ("T-293-1997").

        Returns:
            Id del documento citado o None si no esta en el corpus.
        """
        return self._canon_a_id.get(canon)

    @staticmethod
    def _ano_de_canon(canon: str) -> int | None:
        """Extrae el ano de un canon TIPO-NUM-AAAA.

        Args:
            canon: Canon de sentencia.

        Returns:
            Ano en 4 digitos o None si el canon no tiene el formato esperado.
        """
        try:
            return int(canon.rsplit("-", 1)[1])
        except (IndexError, ValueError):
            return None

    def resolver(self, citas: list[str]) -> list[dict]:
        """Resuelve cada cita canon a su contexto en la red de citas.

        Args:
            citas: Lista de canones TIPO-NUM-AAAA extraidos por M2 (orden de
                aparicion en el texto).

        Returns:
            Lista alineada con citas: para citas resueltas, id del corpus,
            resuelta=True, ano, pagerank (redondeado a 6 decimales) y area
            de la sentencia citada; para no resueltas, id=canon,
            resuelta=False, ano del canon y pagerank/area None.
        """
        salida: list[dict] = []
        for canon in citas:
            id_doc = self._canon_a_id.get(canon)
            if id_doc is None:
                salida.append(
                    {
                        "id": canon,
                        "resuelta": False,
                        "ano": self._ano_de_canon(canon),
                        "pagerank": None,
                        "area": None,
                    }
                )
                continue
            info = self._por_id.get(id_doc)
            salida.append(
                {
                    "id": id_doc,
                    "resuelta": True,
                    "ano": info["ano"] if info else None,
                    "pagerank": round(info["pagerank"], 6) if info else None,
                    "area": info["area"] if info else None,
                }
            )
        return salida
