# Contexto E2 (handoffs entre agentes, máx 20 líneas por entrada)

## Fase A (orquestador, 2026-09-08) — COMPLETADA
- Estructura SEGUNDA ENTREGA creada (plan/decisiones, specs, config, data, scripts/lib, modelos, resultados, figuras, experimentos); E1 queda intacta, E2 lee su CSV.
- Documentos: plan/PLAN.md (maestro con fases A-O), 00_maquina.md + config/hardware.json (venv, 32 hilos, 31 GB RAM, GPU RX 9070 XT 17.1 GB ROCm, Java 26, pyarrow 24), 00_intent.md (producto norte), ADRs 1-5.
- Pendiente instalar en venv: pyspark, transformers, datasets, networkx, sentence-transformers.
## Fase B (nlp-specialist, 2026-09-08) — COMPLETADA
- 10 refs nuevas verificadas (E2 total 20): MultiEURLEX 2021, DoSSIER/COLIEE 2021, Fink 2023, Samy 2021 (NER es), Dozier 2010, McCarthy-Jarvis 2010 (MTLD), Hamilton 2016 (diacronía), Fowler 2007 (PageRank), BETO 2020, E5 2022. Hallazgos: retrieval=BM25 pasajes+rerank denso; E5 zero-shot vs deriva; NER es spaCy híbrido F1 0.93; particiones cronológicas obligatorias.
- Fix orquestador: entrada loffler2025 duplicada en .bib → eliminada (20 entradas OK). E1 intacta.
- Siguiente: Fase C migración Parquet (ml-coder).

## Fase C (ml-coder, 2026-09-08) — COMPLETADA
- Spark 4.2.0 + Java 17 (Java 26 incompatible, documentado en ADR-7 borrador). Parquet Hive 1.465 GB, 23742 filas, limpieza E1 100 % idéntica, ruff OK, E1 intacta.
- Fase D se ejecuta en 3 pasos: D1 script background lemas/stems/POS + lanzamiento; D2 celdas notebook 9.1/9.2/9.6 + lectoras; D3 ejecución lectora tras background + corrida completa.
## Fase D1 (ml-coder, 2026-09-08) — COMPLETADA
- Script eda_ext_lemas_stems_pos.py en nohup (PID 393782, 6.6 docs/s, ETA ~56 min, checkpoints c/500 OK, MTLD media ~60 plausible, POS NOUN>ADP>DET). n_process 12→6 por OOM. Ruff OK, E1 intacta.
## Fase D1-fix (ml-coder, 2026-09-08) — COMPLETADA
- Causa caída: doc 1.4M chars > spaCy max_length 1M (E088). Fix: nlp.max_length=5M (doc máx corpus 3M, id 16989) + guard try/except por doc con log de omitidos. Relanzado PID 48750, reanudó en 1500 → 3500, 0 omitidos, ETA ~1.5 h. Ruff OK.
## Fase D2 (ml-coder, 2026-09-08) — COMPLETADA
- 18 celdas nuevas (24-41), 0 errores, backup md5 OK, celdas 0-23 idénticas. LLR gana colocaciones (75 %); granularidad no supera criterio (párrafo=sentencia; subsentencia 4.64 %).
- REGRESIÓN detectada y corregida por orquestador: re-ejecución borró `nota_raw_previo` de metricas.json → restaurada (resta solo fecha/tiempo, valores idénticos). D3 debe re-preservarla tras cada corrida.
## Incidente background (orquestador, 2026-09-08) — DIAGNOSTICADO
- Workers spaCy murieron en silencio (~doc 7000, docs gigantes multi-MB × 6 workers → OOM; journal confirma OOM-killer activo en la máquina) y el padre quedó colgado esperando el pipe eternamente (sin watchdog). 4 workers huérfanos (~13 GB) hacían trabajo perdido → detenidos por orquestador. RAM 5/31 GB. Checkpoints 500-7000 intactos (reanudación desde 7000).
## Fase D1-fix2 dos fases (ml-coder, 2026-09-08) — COMPLETADA
- Distribución longitudes: >200k=1076 docs (4.5 %), >500k=114, >1M=26, máx 3M. UMBRAL=200k (pipe cubre 95.5 %, lote en vuelo ≤3.2M chars/worker).
- Hallazgo: checkpoints tenían 6990 filas reales (28 omitidos EOFError + 78 bloque perdido) → reanudación por id los recupera. Watchdog: os._exit(3) si pipe sin checkpoint 20 min.
- Relanzado PID 481722: 4 checkpoints nuevos (~4.4 docs/s, c/2 min), RAM 10/31 estable. ETA: pipe ~1 h + largos (868) ~2-6 h + stems.
## Fase D3 (ml-coder, 2026-09-08) — COMPLETADA
- 42/42 OK, EDA intacto certificado (celdas + 5 figuras viejas bit-idénticas, metricas.json valores idénticos + nota restaurada). Clave para ADR-6: con BPE no normalizar; si se normaliza, lema. MTLD T>C>SU; C con VERB en top-5 POS.
## Fase E1 (ml-reviewer, 2026-09-08) — APROBADO (sin cambios)
- 5/5 OK: celdas 0-23 idénticas, limpieza parquet==E1 (200/200), RESUMEN aritmética+cobertura 23742/23742, n-gramas/colocaciones reproducen, granularidad reproduce. Sin bugs mayores ni fixes. Notas: metricas.json solo fecha/tiempo (ya documentado); relativizar rutas (sugerencia); riesgos residuales aceptados.
- Siguiente: Fase E2 QA (ml-qa-engineer).
## Fase E2 (ml-qa-engineer, 2026-09-08) — APROBADO CON OBSERVACIONES
- 6/6 figuras nuevas válidas + 5 viejas bit-idénticas; 12/12 logs legibles (~60k líneas); consistencia a-e OK (top bi/tri exactos, MTLD por tipo OK, metricas.json OK + nota presente, 42 celdas 0 errores). No bloqueantes: sin commit (esperado), nota_ontologias en plan/ (diseño), background en E1 (diseño).
## Fase F (orquestador, 2026-09-08) — COMPLETADA
- ADR-6 (M4: crudo para BPE, lemas para clásicos; stems descartados), ADR-7 aceptado con métricas verificadas, ADR-8 (sentencia completa; subsentencia auxiliar).
## Fase G (ml-coder, 2026-09-08) — COMPLETADA
- CP parseada: 497 filas (384 perm + 112 transit + preámbulo), spot-check 5/5, cobertura por bloque, ruff OK. Fuente Senado HTTP (HTTPS timeout).
## Fase H (ml-coder, 2026-09-08) — COMPLETADA
- NER regex validado (prec 1.00/1.00/1.00/0.90); cobertura CP 98.71 % (clave M3 OK); 516.529 aristas sin self-loops. Incidente rerun colgado → resuelto (249 s).
## Fase I (ml-coder, 2026-09-08) — COMPLETADA
- Etiquetado vía CP: 99.63 % asignadas (cita 98.71 %, fallback 0.92 %, sin área 88 docs). Top: derechos_fund 42.5 %, principios 27.6 %. Ruff OK.
- Nota: Fase J se redefine (D1 ya dio contadores+MTLD globales); J = secuencias de lemas por doc para M4-clásico (background).
## Fase J (ml-coder, 2026-09-08) — SCRIPT EN BACKGROUND
- 05_lematizacion.py (port fiel D1) corriendo PID 883147 (~5.8 docs/s, ETA ~1 h, consistencia lemas 100 % ⊆ ref). Salida final: data/lemas_por_doc.parquet.
- HALLAZGO p/M4: spaCy emite 4507 lemas multi-palabra con espacio ("hacer él", clíticos; 948k ocurr.) → M4 debe normalizar con "hacer_él" o tokenizar en consecuencia.
- Siguiente: Fase K M7 (ml-coder, independiente de J).
## Fase K (ml-coder, 2026-09-08) — COMPLETADA
- M0 accuracy 1.0 (negativos: discursos presidentes vía open_corpus_co_es). Benchmark: cita_exacta F1@5 0.70 (circular, recall 1.0) > BM25 0.119 > E5-CPU 0.090. Deriva temporal: BM25 degrada (0.175→0.088), E5 mejora (0.050→0.109). GPU ocupada por llama-server (~15.7 GB) → E5 en CPU documentado.
- Fix entorno: torchvision reinstalado (torch 2.14+rocm pareja).
- Nota J: OOM en 3000 → relanzado PID 1169131 (reanuda desde 3500), monitorear.
- Fase L: GPU OCUPADA por llama-server → L1 baseline clásico (CPU) ahora, L2 auditoría leakage (reviewer), L3 transformer diferida hasta liberar VRAM.

## Reanudación (2026-09-08 tarde, orden de Carlos: continuar + recalibrar K)
- J reanudado y COMPLETADO: 23742/23742 lemas (6807 s), 195959 tipos = 100 % ref EDA, data/lemas_por_doc.parquet 646 MB.
- K-2 recalibrada (12_evaluar_vinculo_cp_v2.py, GPU): BM25 F1@5 0.218 (+84 %), E5 0.128, híbrido 0.209, cita_exacta ref 0.649. Ventana corta REFUTADA con evidencia (ADR-9). Deriva temporal v1 no se mantiene.
## Fase L1 (orquestador, 2026-09-09) — COMPLETADA
- M4 baseline: LogReg 0.2852 / LinearSVC 0.2654 (completo); gap leakage ≈ 0 (aprende contenido, no citas). Splits guardados UNA VEZ. LightGBM descartado por RAM (3 muertes silenciosas, máquina compartida con UKAN externo).
## Fase L2 (ml-reviewer, 2026-09-09) — RECHAZO v1 → CORRECCIÓN → v2 OK
- Reviewer RECHAZÓ el enmascarado v1 (0.7 CITA/doc vs 10.7 citas reales; nucleos sin tilde; romanos falsos) pero demostró SIN leakage activo (prueba de oro: features cita solas → F1 0.0611 ≈ azar 1/16; is_alpha ya eliminó números; top-20 temático).
- Orquestador corrigió enmascarado (nucleos con tilde + plurales, romano estricto, series "11 y 13") + shap trazable para cualquier mejor modelo. Re-ejecución v2: LogReg 0.2852/0.2870, gap −0.0018 (enmascarado incluso mejor). Gate L2 SUPERADO con v2.
## Fase M (ml-coder, 2026-09-09) — COMPLETADA
- M5: PageRank landmarks fundacionales (C-224/1992 top); 456k aristas resueltas; gigante 67.6 %. M6: principios +20 pp / derechos_fund −24 pp; léxico conflicto→posacuerdo→pandemia; MTLD 64.9→56.8.
- L3 (07_transformer.py) lanzado con guard VRAM: espera a que el UKAN externo libere GPU (intento 10+, cada 5 min, máx 24 h).
## Fase N (ml-coder, 2026-09-09) — COMPLETADA
- Producto end-to-end OK: 3 demos (T-293/97 true 0.943, C-002/98 true 0.934, discurso false). ~9 s/eval. Componentes en lib/, CLI en 10_evaluar_sentencia.py.
## Fase L3 (2026-09-09 19:05) — COMPLETADA
- BETO 3 épocas 256+256: test completo 0.2080 / enmascarado 0.2042, gap 0.0039 (sin leakage). LogReg GANA (0.2870) — ventana 512 tokens descarta ~95 % de docs de ~11k palabras. ADR-10 aceptado: producto conserva LogReg sin cambios; BETO en modelos/m4_transformer/.
- Siguiente: QA final del producto (ml-qa-engineer) → Fase O bajo pedido de Carlos.
