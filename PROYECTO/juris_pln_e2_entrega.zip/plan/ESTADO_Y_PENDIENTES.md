# PLAN MAESTRO E2 "Juris-PLN" — Estado y pendientes
Actualizado: 2026-09-09 · Fuente de verdad: `plan/PLAN.md` (fases) + este resumen ejecutivo.

## Producto norte
Sistema que, dada una sentencia de la Corte Constitucional: (1) valida que sea
providencia de la Corte, (2) determina su área temática constitucional,
(3) identifica los artículos de la CP que la sustentan (robusto a deriva
temporal), (4) la sitúa en su contexto jurisprudencial (precedentes y
evolución 1992-2021).

## Fases COMPLETADAS (13 de 15)

| Fase | Contenido | Resultado clave |
|---|---|---|
| A | Estructura SEGUNDA ENTREGA + PLAN.md + ADRs 1-5 + hardware | Docs base listos |
| B | SOTA ampliado ES+EN (nlp-specialist) | 10 refs nuevas verificadas (total 20 en .bib): COLIEE/DoSSIER, Fink 2023, Samy 2021 (NER es), MTLD, Hamilton 2016, Fowler 2007, BETO, E5 |
| C | Migración CSV→Parquet (ADR-7) | PySpark 4.2 + Java 17 (Java 26 incompatible); 23.742 filas, limpieza 100 % idéntica E1; 1.56→1.47 GB |
| D | EDA extendido (sección 9 notebook E1, celdas 0-23 intactas) | N-gramas (top tri "accion de tutela" 344.893), colocaciones (gana LLR 75 %), lema-vs-stem (lemas 87.3 %, stems 54.2 %), POS (NOUN>ADP>DET), MTLD 61.03, granularidad (sentencia completa; subsentencia 4.64 % no supera criterio) |
| E | Review + QA del EDA | Reviewer APROBADO (5/5); QA APROBADO C/OBS (figuras 6/6, logs 12/12, consistencia OK) |
| F | ADRs 6-8 con números del corpus | ADR-6 (crudo para BPE, lemas para clásicos), ADR-7 (aceptado), ADR-8 (sentencia completa) |
| G | Constitución: descarga + parseo (M3) | 497 artículos (384 perm + 112 transitorios + preámbulo) → 19 bloques temáticos; spot-check 5/5 |
| H | NER jurídico corpus completo (M2) | Precisión muestral 1.00/1.00/1.00/0.90; cobertura CP 98.71 %; 516.529 aristas sin self-loops |
| I | Etiquetado de áreas (M3) | 99.63 % asignadas (cita CP 98.71 %, fallback 0.92 %); top: derechos_fundamentales 42.5 % |
| J | Lemas por documento (M1) | 23.742/23.742; vocabulario 195.959 tipos = 100 % coincidente con referencia EDA; data/lemas_por_doc.parquet |
| K | M0 validación + M7 benchmark retrieval (v1) | M0 accuracy 1.0 (30 pos + 22 neg discursos); v1: cita_exacta 0.70 (circular) > BM25 0.119 > E5-CPU 0.090 |
| K-2 | Recalibración M7 (petición de Carlos) | BM25 F1@5 0.119→**0.218 (+84 %)**, MRR 0.717; E5 GPU 0.128; híbrido 0.209; 90 casos (3/año); ADR-9: ventana corta REFUTADA con evidencia (1ª cita a mediana 41 % del texto); mejora real = pasajes por artículo + max-pooling chunks + stopwords jurídicas + bigramas LLR |
| L1 | M4 baseline clásico | Splits 70/15/15 UNA VEZ (16.557/3.549/3.548); TF-IDF lemas 100k; LinearSVC 0.2654/0.2657, LogReg 0.2852/**0.2870** (completo/enmascarado); accuracy ~59 % |
| L2 | Auditoría leakage (gate crítico) | Reviewer RECHAZÓ enmascarado v1 (0.7 CITA/doc vs 10.7 citas reales) → corregido (núcleos con tilde, romanos estrictos, series) → v2 gap −0.0018 (enmascarado incluso mejor); prueba de oro: features de cita solas → F1 0.0611 ≈ azar → SIN leakage activo |
| M | M5 red de citas + M6 diacronía | Grafo 23.742 nodos / 456.321 aristas (84.5 % resueltas), gigante 67.6 %; PageRank top: C-224/1992, SU-2716/1997 (landmarks fundacionales); evolución: cita precedentes cada vez más recientes. Áreas: principios +20.2 pp, derechos_fund −24.2 pp. Léxico: incoder/rupd→covid/jep/coronavirus. MTLD 64.9→56.8 (prosa menos diversa) |
| N | PRODUCTO end-to-end | `10_evaluar_sentencia.py` (CLI --archivo/--id/--texto) + `lib/componentes_producto.py`; JSON: validación, ponente, área top-3 con prob, arts CP extraídos+BM25, citas con PageRank/área, resumen. Demo: T-293/97 (true, 0.943), C-002/98 (true, 0.934), discurso (false 0.0). ~9 s/eval |

## PENDIENTE (2 fases + cierre)

### 1. Fase L3 — Transformer BETO — COMPLETADA 2026-09-09 19:05
- Guard de VRAM funcionó: esperó 3h05m (37 intentos) hasta que el UKAN
  externo liberó la GPU; arrancó solo a las 15:29.
- Fine-tuning BETO (bert-base-spanish-wwm-cased), 3 épocas, batch efectivo
  32, truncamiento cabeza+cola 256+256 (ADR-3), 6h40m totales GPU.
- Resultados: completo macro-F1 test **0.2080** (acc 51.7 %), enmascarado
  **0.2042** (acc 51.3 %), gap leakage 0.0039 (consistente con L2: sin
  leakage). Curvas sanas (val 0.13→0.19→0.21 en ambos escenarios).
- **BENCHMARK 2×2 FINAL (macro-F1 test)**:
  | Modelo | Completo | Enmascarado |
  |---|---|---|
  | LogReg+TF-IDF lemas (M4) | 0.2852 | **0.2870** |
  | BETO fine-tuned (L3) | 0.2080 | 0.2042 |
- **Veredicto: LogReg GANA** → el producto conserva ClasificadorArea con
  LogReg (sin cambios). BETO pierde por diseño del corpus: docs ~11k
  palabras vs ventana 512 tokens (~95 % del contenido descartado por el
  truncamiento), mientras TF-IDF ve el documento completo. Documentado en
  ADR-10. Modelos BETO guardados en modelos/m4_transformer/ por
  reproducibilidad.
- Siguientes pasos: QA final del producto (ml-qa-engineer) → Fase O bajo
  pedido de Carlos.

### 2. QA final del producto (ml-qa-engineer)
- Tras L3: verificación end-to-end del producto con más casos (los 3 de la
  demo + muestra aleatoria estratificada), consistencia de métricas
  acumuladas (m4_baseline.json, m4_transformer.json, vinculo_cp_benchmark_v2,
  red_citas.json, diacronia.json), checklist de entrega (skill ml-shipping:
  GO/NO-GO con rollback).

### 3. Fase O — Cierre (SOLO bajo pedido de Carlos)
- Demo interactiva (streamlit) — opcional.
- Informe final E2 (CRISP-DM o LaTeX) + deck de diapositivas.
- Validación cruzada extendida (notebook ↔ resultados ↔ informe).
- Zip de entrega.
- Git: commit + PR (flujo E1: rama → push → PR → merge → borrar rama remota).
  NADA commiteado aún por acuerdo (git solo bajo pedido).

## Decisiones ADR registradas (plan/decisiones/)
1. Etiquetado de área vía Constitución · 2. Anti-leakage doble escenario ·
3. Docs largos: truncamiento cabeza+cola + chunk-mean · 4. Scripts SOLID +
   notebook E1 intacto · 5. Vínculo CP: weak labels + 1/año · 6. M4: crudo
   para BPE, lemas para clásicos · 7. PySpark+Parquet · 8. Granularidad:
   sentencia completa · 9. Retrieval: pasajes + max-pooling (ventana corta
   refutada).

## Incidentes y lecciones (para el informe)
- Java 26 incompatible con Spark 4.2 → Java 17 (documentado en ADR-7).
- 3 muertes silenciosas por RAM al competir con jobs externos (llama-server,
  UKAN): mitigado con n_process reducido, checkpoints por id y reanudación
  automática (funcionó 3 veces); LightGBM-sobre-TF-IDF sustituido por LogReg.
- spaCy max_length 1M < doc máx 3M → nlp.max_length=5M + guard por doc.
- Enmascarado v1 inválido (detectado por auditoría adversarial L2): los
  números arábigos ya no existen en los lemas (is_alpha) y los núcleos de
  cita llevan tilde ("artículo") → corregido en v2.
- E5 en CPU en K v1 (GPU ocupada); K-2 ya en GPU.

## Cifras canónicas del sistema (fuente: resultados/*.json)
- Corpus: 23.742 sentencias (T 17.099 / C 6.246 / SU 397), 1992-2021.
- Etiquetado: 99.63 % cobertura, 16 clases efectivas.
- M4 clásico: LogReg macro-F1 0.2870 (enmascarado), gap leakage ≈ 0.
- M7 retrieval: BM25 v2 F1@5 0.218 / MRR 0.717 (vs cita-exacta 0.649 ref).
- M0: accuracy 1.0 (52 casos: 30 positivos + 22 negativos).
- Producto: ~9 s por evaluación end-to-end.
